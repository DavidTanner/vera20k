"""One-off execution receipt producer using the shared preserved-artifact owner."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import time

from tools.cargo_run import build_store, preserved_manifest, preserved_artifact
from tools.spatial_oracle.astar_path_finishing_replay import check_hash_composition, rows

ROOT = Path('/Users/halvor/Documents/vera20k/.claude/worktrees/unit-draw-type')
EVIDENCE = Path('/Users/halvor/Documents/vera20k-dev/evidence/siege-chopper-deployed-draw-20261002')
PREP = EVIDENCE / 'hash-control-preparation'
CORPUS = ROOT / 'tools/spatial_oracle/unit_simple_deploy_replay'
LABEL = 'siege-chopper-hash-control-20261002'
GATE = 'VERA20K_DIAGNOSTIC_LEGACY_UNIT_DEPLOY_HASH'
FIXTURES = {
    'bridge': (201, 0xE3FD9DD363C98F82, 0xF6E02080D0BE29C1),
    'global': (601, 0x851C57C576CA991A, 0xC86F736CE95687B3),
    'slice6': (17, 0x1AD1402910CE62D8, 0xB20E11E0579BC4E4),
}
CORPUS.mkdir(exist_ok=True)
assert not (CORPUS / 'receipt.json').exists(), 'do not replace a retained receipt'
store, _ = build_store(ROOT)
directory, target, artifacts = preserved_manifest(store, LABEL)
assert len(artifacts) == 1
artifact = artifacts[0]
binary = preserved_artifact(directory, artifact)
manifest_bytes = (directory / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
source_sha = manifest['source']['source_sha256']
command = [str(binary), '--exact',
    'sim::world::bridge_parity_harness_tests::bridge_crossing_replay_is_deterministic_and_baseline_stable',
    'sim::world::global_parity_harness_tests::global_skirmish_replay_is_deterministic_and_baseline_stable',
    'sim::world::slice6_retask_tests::replay_hash_stable_through_slice6',
    '--nocapture', '--test-threads=1']
inputs = []


def retain(name, raw, **metadata):
    data = gzip.compress(raw, mtime=0) if name.endswith('.gz') else raw
    destination = CORPUS / name
    assert not destination.exists(), destination
    destination.write_bytes(data)
    inputs.append(dict(file=name, sha256=hashlib.sha256(data).hexdigest(),
                       raw_sha256=hashlib.sha256(raw).hexdigest(), **metadata))


retain('build-manifest.json', manifest_bytes)
retain('build.log.gz', (EVIDENCE / 'hash-control-build-retry.log').read_bytes())
patch = ((PREP / 'world-hash-control.patch').read_bytes()
         + (PREP / 'expected-pins-control.patch').read_bytes())
retain('temporary-control.patch.gz', patch)
retain('execution-producer.py.gz', Path(__file__).read_bytes())
for mode, enabled in (('control', '1'), ('current', None)):
    output = EVIDENCE / f'hash-control-{mode}'
    output.mkdir()
    env = dict(os.environ, VERA20K_REQUIRE_RETAIL_INI='1',
               VERA20K_REPLAY_DIAGNOSTICS=str(output))
    env.pop(GATE, None)
    if enabled is not None:
        env[GATE] = enabled
    preserved_artifact(directory, artifact)
    started = time.monotonic()
    with (output / 'run.log').open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    seconds = time.monotonic() - started
    preserved_artifact(directory, artifact)
    execution = dict(schema_version=1, mode=mode, command=command, cwd=str(ROOT),
        exit_code=result.returncode, seconds=seconds, binary_sha256=artifact['sha256'],
        binary_unchanged=True, source_sha256=source_sha, legacy_unit_deploy_hash=enabled)
    retain(f'{mode}.execution.json', (json.dumps(execution, indent=2) + '\n').encode())
    retain(f'{mode}.log.gz', (output / 'run.log').read_bytes())
    assert result.returncode == 0, (mode, result.returncode, str(output / 'run.log'))
    for fixture, (count, old_pin, new_pin) in FIXTURES.items():
        data = (output / f'{fixture}.jsonl').read_bytes()
        observations = rows(data)
        assert len(observations) == count
        assert observations[-1]['tick_result']['state_hash'] == (old_pin if enabled else new_pin)
        retain(f'{mode}-{fixture}.jsonl.gz', data, mode=mode, fixture=fixture)
    print(json.dumps({'mode': mode, 'exit_code': result.returncode, 'seconds': seconds}), flush=True)
receipt = dict(schema_version=1, kind='same-binary-rust-hash-composition',
    scope='Rust-only attribution of Unit6E0, Techno130/134 and persistent voxel Unit Foot538 hash feeds; not native replay parity',
    binary=dict(manifest_file='build-manifest.json', sha256=artifact['sha256'],
                source_sha256=source_sha, label=LABEL),
    gate=dict(file='temporary-control.patch.gz', sha256=hashlib.sha256(patch).hexdigest(),
              environment=GATE, removal_required_before_final_checks=True,
              effect='Hash reads only: omit asserted-zero Unit6E0; replace absent deploy attachment/false landing with prior deploy_state=None u8; fold zero for voxel Unit body counter without altering its live value. Final expected test pins switch to known incoming values only in control mode.'),
    runs={mode: dict(receipt_file=f'{mode}.execution.json') for mode in ('control', 'current')},
    incoming_main=dict(head=manifest['source']['head'], pins={name: values[1] for name, values in FIXTURES.items()}),
    inputs=inputs,
    comparisons=[dict(fixture=name, rows=values[0], control_hash=values[1], current_hash=values[2])
                 for name, values in FIXTURES.items()],
    normalization=['tick_result.state_hash only'],
    limits=['One unchanged Rust binary and three supplied synthetic fixtures, not a native whole-match certificate.',
            'All serialized observations, retained House/Factory inputs, three RNG states and ordered draw/caller texts match in both modes after removing only the tick hash.',
            'Hash-only control restores incoming pins but does not claim unobserved native routes are implemented.'])
path = CORPUS / 'receipt.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
result = check_hash_composition(path)
(CORPUS / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
