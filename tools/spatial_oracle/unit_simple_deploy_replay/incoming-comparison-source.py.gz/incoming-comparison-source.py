"""Retained one-off supplementary audit; arguments: checkout corpus_directory.

Uses the existing comparison owner. Two explicit historical call-frame mappings
are supplementary only; the main off/on proof removes just tick_result.state_hash.
"""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import re
import sys

from tools.native_oracle import first_difference
from tools.spatial_oracle.astar_path_finishing_replay import normalized, rows

CHECKOUT = Path(sys.argv[1]).resolve()
CORPUS = Path(sys.argv[2]).resolve()
PRIOR_DISPATCH_REFACTOR = '1b9ec6658301ed7cf3caee624fbc9ca7202a0e66'


def frames(callers):
    result = []
    for item in re.split(r'^\s*\d+: ', callers, flags=re.M)[1:]:
        lines = item.rstrip().splitlines()
        result.append((lines[0], tuple(line.strip() for line in lines[1:])))
    return result


def project_prior_dispatch(callers):
    result = []
    for name, location in frames(callers):
        if name == 'dispatch_supported_foot_mission_cadence':
            assert location == ('at ./src/sim/world/techno_ai/mission_handlers.rs:<line>:<column>',)
            name = 'dispatch_foot_mission'
        if name == 'dispatch_harvest_for_object':
            assert location == ('at ./src/sim/miner/harvest_mission.rs:<line>:<column>',)
            result.append(('mission_harvest', location))
            result.append(('dispatch_foot_mission', ('at ./src/sim/world/techno_ai/mission_handlers.rs:<line>:<column>',)))
        else:
            result.append((name, location))
    return result


report = {
    'scope': 'saved incoming Rust observations vs candidate; not native replay parity',
    'projection': [
        'tick_result.state_hash omitted',
        'verified old deploy_state=null and new deploy_anim=null/landing_for_deploy=false omitted',
        'verified new Unit deployed=0 omitted',
        'voxel Unit body counter set only in comparison to verified incoming zero',
        'incoming Unit voxel_animation removed only in comparison; candidate is null',
        'RNG caller source line/column normalized',
        'two exact prior dispatch frame substitutions from ancestor commit ' + PRIOR_DISPATCH_REFACTOR,
    ],
    'comparisons': [],
}
for fixture in ('bridge', 'global', 'slice6'):
    old_path = CHECKOUT / 'tools/spatial_oracle/engineer_repair_replay' / f'current-{fixture}.jsonl.gz'
    new_path = CORPUS / f'current-{fixture}.jsonl.gz'
    old_data = gzip.decompress(old_path.read_bytes())
    new_data = gzip.decompress(new_path.read_bytes())
    old, new = rows(old_data), rows(new_data)
    assert len(old) == len(new)
    a = normalized(old, omit_tick_hash=True, callers=True)
    b = normalized(new, omit_tick_hash=True, callers=True)
    counters, voxel_forms = Counter(), Counter()
    caller_differences = []
    for index, (before, after) in enumerate(zip(a, b)):
        assert len(before['entities']) == len(after['entities'])
        for u, v in zip(before['entities'], after['entities']):
            assert u['stable_id'] == v['stable_id']
            assert u.pop('deploy_state') is None
            assert v.pop('deploy_anim') is None
            assert v.pop('landing_for_deploy') is False
            if 'Unit' in u['mission_leaf']:
                assert v['mission_leaf']['Unit'].pop('deployed') == 0
            if u['category'] == 'Unit' and u['is_voxel']:
                assert v['category'] == 'Unit' and v['is_voxel']
                assert u['body_frame_counter'] == 0
                counters[v['body_frame_counter']] += 1
                v['body_frame_counter'] = 0
                voxel_forms[json.dumps(u['voxel_animation'], sort_keys=True)] += 1
                assert v['voxel_animation'] is None
                u['voxel_animation'] = None
        assert len(before['draws']) == len(after['draws'])
        for draw, (u, v) in enumerate(zip(before['draws'], after['draws'])):
            left, right = u.pop('callers'), v.pop('callers')
            difference = first_difference(project_prior_dispatch(left), frames(right))
            if difference:
                caller_differences.append({'boundary': index, 'draw': draw, 'difference': difference})
    report['comparisons'].append({
        'fixture': fixture, 'rows': len(a),
        'incoming_raw_sha256': hashlib.sha256(old_data).hexdigest(),
        'candidate_raw_sha256': hashlib.sha256(new_data).hexdigest(),
        'incoming_pin': old[-1]['tick_result']['state_hash'],
        'candidate_pin': new[-1]['tick_result']['state_hash'],
        'voxel_unit_observations': sum(counters.values()),
        'changed_nonzero_voxel_unit_counters': sum(count for value, count in counters.items() if value),
        'max_voxel_unit_counter': max(counters),
        'incoming_voxel_animation_forms': dict(voxel_forms),
        'remaining_gameplay_difference': first_difference(a, b),
        'remaining_caller_differences': caller_differences,
    })
output = CORPUS / 'incoming-comparison.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
assert all(row['remaining_gameplay_difference'] is None and not row['remaining_caller_differences']
           for row in report['comparisons'])
