#!/usr/bin/env python3
"""External bounded guards; reuse the repository's comparison owners."""
import argparse
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--checkout", type=Path, required=True)
parser.add_argument("--control", type=Path, required=True)
parser.add_argument("--current", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.checkout.resolve()))
from tools.spatial_oracle.astar_path_finishing_replay import normalized, rows
from tools.native_oracle import first_difference

counts = {"bridge": 201, "global": 601, "slice6": 17}
zero_stats = dict(units_killed=0, buildings_killed=0, units_lost=0,
                  buildings_lost=0, built=0, score_points=0)
zero_dirty_power = dict(total_output=0, total_drain=0, has_drained_power_source=False,
                        is_low_power=False, blackout_timer=dict(start_frame=0, duration=0),
                        was_low_power=False, theoretical_total_power=0,
                        power_dirty=True, radar_dirty=True, radar_available=False)

def require(condition, label):
    if not condition:
        raise AssertionError(label)

for fixture, count in counts.items():
    exports = {}
    for mode, directory in [("control", args.control), ("current", args.current)]:
        observations = rows((directory / f"{fixture}.jsonl").read_bytes(), strict=True)
        require(len(observations) == count, f"{fixture}/{mode}: boundary count")
        exports[mode] = observations
        for index, row in enumerate(observations):
            label = f"{fixture}/{mode}/boundary{index}"
            require(row["next_frame"] == index, f"{label}: native frame")
            state = row["retained_path_inputs"]["engineer_house_attribution"]
            require(state["house_order"] == [] and state["current_house"] is None,
                    f"{label}: supplied House boundary changed")
            require(state["factory_count"] == 0 and state["factories"] == [],
                    f"{label}: no production route")
            for entity in row["entities"]:
                require(entity["capture_infantry_type_index"] == -1,
                        f"{label}: capture index write on {entity['stable_id']}")
                require(not entity["has_been_captured"], f"{label}: capture lifecycle")
                if entity["category"] == "Structure":
                    require(fixture == "global" and entity["stable_id"] in [1, 2],
                            f"{label}: unexpected Building")
                    require(entity["health"]["current"] == 1000, f"{label}: Building HP")
                    require(entity["building_power_health_sample"] == (0 if index == 0 else 1000),
                            f"{label}: first native Building sample")
            houses = {house["owner"]: house for house in state["houses"]}
            require(all(not house["capture_notified"] and not house["discovered_by_current_house"]
                        for house in houses.values()), f"{label}: House notification")
            if fixture != "global":
                require(houses == {} and state["power_states"] == [],
                        f"{label}: headless fixture acquired a House/cache")
            else:
                require(set(houses) == {"Americans", "Soviet"}, f"{label}: House registry")
                require(state["power_states"] == [dict(owner="Americans", state=zero_dirty_power)],
                        f"{label}: retained zero dirty power cache")
                require(houses["Americans"]["building_order"] == [1, 2],
                        f"{label}: House Building storage order")
                require(houses["Soviet"]["building_order"] == [], f"{label}: Soviet Buildings")
                for owner, house in houses.items():
                    expected = dict(zero_stats)
                    if index >= 588:
                        expected["units_lost" if owner == "Americans" else "units_killed"] = 1
                    require(house["stats"] == expected, f"{label}: ordinary RecordTheKill {owner}")
    difference = first_difference(normalized(exports["control"], omit_tick_hash=True),
                                  normalized(exports["current"], omit_tick_hash=True))
    require(difference is None, f"{fixture}: complete observation delta: {difference}")
print(json.dumps({"scope":"source-derived path guards plus same-binary comparison",
                  "boundaries":sum(counts.values()),"fixtures":counts}, indent=2))
