"""Binding-only reuse of saved actual native payload through its existing CLI publisher."""
from pathlib import Path
import json,runpy,sys
sys.path.insert(0,str(Path.cwd()))
from tools import native_oracle as owner
original=owner.finish_vectors
module=sys.argv[1]; sys.argv=[module,*sys.argv[2:]]
def bound_saved_payload(data,default_path,**kwargs):
    # The selected generator is deliberately not executed. Prior actual VM
    # receipts and the diagnostics-only success audit establish this factor.
    saved=json.loads(Path(default_path).read_text())
    print('BINDING ONLY: saved original payload; native generator not executed',flush=True)
    original(saved,default_path,**kwargs)
owner.finish_vectors=bound_saved_payload
if module=='tools.spatial_oracle.anytown_damage.unit_unlimbo':
    import importlib
    importlib.import_module(module).publish(argv=sys.argv[1:])
else:
    runpy.run_module(module,run_name='__main__',alter_sys=True)
