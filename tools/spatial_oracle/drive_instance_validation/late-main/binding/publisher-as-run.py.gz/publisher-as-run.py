from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
base=Path('/Users/halvor/Documents/vera20k-dev/refactor-goal/drive-instance-680-late-d2-bindings-20261003')
base.mkdir()
helper=base.parent/'native-diagnostics-factorized-child-20261003.py'
source_key='source_normalized_lf_sha256'
paths=[root/p for p in subprocess.check_output(['git','ls-files','tools/spatial_oracle'],cwd=root,text=True).splitlines() if p.endswith('.json') and not p.endswith('.meta.json')]
payloads={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
metas={str(p.relative_to(root)):p.read_bytes() for p in (root/'tools/spatial_oracle').rglob('*.meta.json')}
freeze={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for directory,ext in [('src','*.rs'),('tools','*.py')] for p in (root/directory).rglob(ext)}
jobs=[('tools.spatial_oracle.locomotor_head_coordinates',[], 'tools/spatial_oracle/locomotor_head_coordinates.meta.json')]
receipt={'status':'RUNNING','scope':'Refresh one frontend atlas-call source stamp after main d2; saved original Compass payload publisher','fresh_native_vm_generation':False,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'protected_json_count':len(payloads),'protected_metadata_count':len(metas),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'runs':[],'changed_source_pins':{}}
for module,options,rel in jobs:
 staged=base/('staged-'+Path(rel).name.replace('.meta.json','.json'))
 for mode in ['write','check']:
  args=[*options,'--'+mode]
  if mode=='write':args+=['--output',str(staged)]
  log=base/(Path(rel).stem+'-'+mode+'.log')
  started=time.monotonic()
  with log.open('w') as out:code=subprocess.run([sys.executable,str(helper),module,*args],cwd=root,stdout=out,stderr=subprocess.STDOUT).returncode
  receipt['runs'].append({'module':module,'args':args,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
  print(module,mode,'exit',code,flush=True)
  assert code==0,log
  if mode=='write':
   incoming=staged.with_suffix('.meta.json');old=json.loads(metas[rel]);new=json.loads(incoming.read_text())
   assert {k:v for k,v in old.items() if k!=source_key}=={k:v for k,v in new.items() if k!=source_key},'nonbinding provenance changed'
   changed={p for p,h in new[source_key].items() if old[source_key].get(p)!=h}
   assert changed=={'src/app/frontend/skirmish.rs'},changed
   assert hashlib.sha256((root/'src/app/frontend/skirmish.rs').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==new[source_key]['src/app/frontend/skirmish.rs']
   assert json.loads(staged.read_text())==json.loads((root/rel).with_name(Path(rel).name.replace('.meta.json','.json')).read_text()),'native payload changed'
   (root/rel).write_bytes(incoming.read_bytes());receipt['changed_source_pins'][rel]=sorted(changed)
selected={rel for _,_,rel in jobs}
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in payloads.items())
assert all((root/p).read_bytes()==data for p,data in metas.items() if p not in selected)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
receipt.update(status='PASS',all_tracked_json_raw_byte_exact=True,all_nonbinding_provenance_exact=True,source_freeze_preserved=True)
(base/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS 2 binding-only calls; one source pin; all JSON/nonbinding provenance exact',flush=True)
