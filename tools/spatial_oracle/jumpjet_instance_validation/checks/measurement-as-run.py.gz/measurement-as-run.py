"""One owned regression measurement; all repository writers must be frozen."""
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import time

from tools.cargo_run import source_identity

root = Path.cwd()
base = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
selector = sys.argv[1]
attempt = sys.argv[2] if len(sys.argv) > 2 else 'r0'
assert attempt.isalnum(), 'attempt must be a short alphanumeric identifier'
expected = sys.argv[3] if len(sys.argv) > 3 else 'red'
assert expected in ('red', 'green')
plan_path = base / 'movement-target-689-final-validation-invocation-plan-20261003.json'
plan = json.loads(plan_path.read_text())
mode = {'@full': 'full_lib', '@clippy': 'clippy_lib', '@primary63': 'primary63',
        '@python': 'python_suite', '@release': 'release_game'}.get(selector)
if mode:
    assert expected == 'green' and len(sys.argv) == 4
    if mode == 'python_suite':
        args = []
    elif mode == 'release_game':
        args = ['build', '-p', 'vera20k', '--release', '--bin', 'vera20k']
    else:
        args = plan[mode]['args'] if mode == 'primary63' else plan[mode]
    name = f'movement-target-689-final-{mode}-{attempt}-20261003'
else:
    args = ['test', '-p', 'vera20k', '--lib', '--', '--nocapture', selector, *sys.argv[4:]]
    name = f'movement-target-689-regression-{expected}-{attempt}-20261003'
argv = ([sys.executable, '-m', 'tools.run_tests'] if mode == 'python_suite' else
        [sys.executable, '-m', 'tools.cargo_run', '--', *args])


def sources():
    paths = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard',
         '*.rs', '*.py'], text=True).splitlines()
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest()
            for path in sorted(set(paths)) if (root / path).is_file()}


before = sources()
identity = source_identity(root)
started = time.time()
log = base / (name + '.log')
assert not log.exists(), 'preserve the earlier measurement; use a fresh attempt'
env = dict(os.environ, **plan['required_env'], **plan['map_overrides'])
assert all(Path(path).is_file() for path in plan['map_overrides'].values())
with log.open('w') as out:
    result = subprocess.run(argv, stdout=out, stderr=subprocess.STDOUT, env=env)
after = sources()
output = log.read_text()
summary = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output)
fixture_skip = bool(re.search(r'SKIPPED|Skipping', output))
receipt = dict(cwd=str(root), argv=argv, cargo_run_exit=result.returncode,
               wall_seconds=time.time() - started, source_identity=identity,
               source_files=before, source_unchanged=before == after,
               compile_error=mode != 'python_suite' and 'error[E' in output,
               observed_test_failure='test result: FAILED.' in output,
               log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
               mode=mode or 'focused', test_summaries=summary, fixture_skip_marker=fixture_skip,
               invocation_plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest())
(base / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items()
                  if key not in ('source_files', 'source_identity')}, indent=2), flush=True)
print('source_count', len(before), flush=True)
print('\n'.join(output.splitlines()[-35:]), flush=True)
assert before == after, 'source changed during regression measurement'
if expected == 'red':
    assert result.returncode == 101 and receipt['observed_test_failure'] and not receipt['compile_error'], \
        'measurement did not reach the intended failing test'
else:
    assert result.returncode == 0 and not receipt['observed_test_failure'] and not receipt['compile_error'], \
        'validation did not pass'

if mode == 'primary63':
    assert len(summary) == 1 and tuple(map(int, summary[0][:4])) == (63, 0, 0, 0)
    assert not fixture_skip, 'a required retail assertion skipped its fixture'
