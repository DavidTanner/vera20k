"""Extend the existing byte-preserving #689 archive; one-off publication owner."""
from pathlib import Path
import gzip
import hashlib
import json
from tools.cargo_run import source_identity

ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
DEST = ROOT / 'tools/spatial_oracle/jumpjet_instance_validation'
PLAN = BASE / 'movement-target-689-late-main-archive-plan-20261003.json'
plan = json.loads(PLAN.read_text())
manifest_path = DEST / 'archive-sha256.json'
old = json.loads(manifest_path.read_text())
assert len(old) == plan['old_records'] == 111
assert not (DEST / 'late-main').exists()

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert sha(manifest_path.read_bytes()) == plan['old_manifest_sha256']
for relative, record in old.items():
    assert sha((DEST / relative).read_bytes()) == record['archive_sha256'], relative
for item in plan['pairs']:
    assert Path(item['source']).is_file(), item['source']
release = json.loads((BASE / 'movement-target-689-final-release_game-r1-20261003.json').read_text())
assert release['cargo_run_exit'] == 0 and release['source_unchanged']
assert source_identity(ROOT) == release['source_identity']
assert all(sha((ROOT / rel).read_bytes()) == digest for rel,digest in release['source_files'].items())
proof = json.loads((BASE / 'movement-target-689-jumpjet-late-main-runtime-proof-20261003.json').read_text())
assert proof['status'] == 'PASS' and proof['exact_rust_python_sources'] == 1962
for item in plan['runs']:
    report=json.loads((Path(item['source'])/'run.json').read_text())
    assert report['status']=='VALID' and report['child']['exit_status']==0
    assert not report['child']['timed_out']
records = {}

def preserve(source, relative, compressed=True):
    target = DEST / relative
    assert not target.exists(), relative
    target.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    with target.open('xb') as stream:
        if compressed:
            with gzip.GzipFile(filename='', fileobj=stream, mode='wb', compresslevel=9, mtime=0) as archive:
                archive.write(data)
        else:
            stream.write(data)
    retained = target.read_bytes()
    assert (gzip.decompress(retained) if compressed else retained) == data
    assert source.read_bytes() == data
    records[relative] = {'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                         'archive_bytes': len(retained), 'archive_sha256': sha(retained), 'gzip': compressed}

preserve(DEST/'README.md','late-main/before/README.md.gz')
preserve(manifest_path,'late-main/before/archive-sha256.json.gz')
for item in plan['pairs']:
    preserve(Path(item['source']),item['relative'],item['compress'])
for item in plan['runs']:
    directory=Path(item['source'])
    for source in sorted(directory.rglob('*')):
        if not source.is_file() or source.name=='config.toml':
            continue
        relative=source.relative_to(directory).as_posix()
        compressed=source.name!='profile.json'
        preserve(source,'late-main/runtime/'+item['label']+'/'+relative+('.gz' if compressed else ''),compressed)
preserve(PLAN,'late-main/archive-plan.json.gz')
preserve(Path(__file__),'late-main/archive-as-run.py.gz')

labels = (
 ('full-r1','movement-target-689-final-full_lib-r1-20261003',0),
 ('clippy-r1','movement-target-689-final-clippy_lib-r1-20261003',0),
 ('python-p2','movement-target-689-final-python_suite-p2-20261003',0),
 ('primary63-r1-failed','movement-target-689-final-primary63-r1-20261003',101),
 ('primary63-r2','movement-target-689-final-primary63-r2-20261003',0),
 ('release-r1','movement-target-689-final-release_game-r1-20261003',0),
 ('r2debug','movement-target-689-regression-red-r2debug-20261003',101),
 ('g6','movement-target-689-regression-green-g6-20261003',101),
 ('r3inputs','movement-target-689-regression-red-r3inputs-20261003',101),
 ('g7','movement-target-689-regression-green-g7-20261003',101),
 ('r4fire','movement-target-689-regression-red-r4fire-20261003',101),
 ('g8','movement-target-689-regression-green-g8-20261003',0))
runs=[]
for label,stem,expected_exit in labels:
    receipt=json.loads((BASE/(stem+'.json')).read_text())
    assert receipt['cargo_run_exit']==expected_exit and receipt['source_unchanged']
    assert sha((BASE/(stem+'.log')).read_bytes())==receipt['log_sha256']
    runs.append({key:receipt.get(key) for key in ('mode','argv','cargo_run_exit','wall_seconds',
                'source_identity','test_summaries','fixture_skip_marker','log_sha256')} | {'label':label})
summary={'classification':'late-main validation and bounded Rust release evidence; failed diagnostics retained',
 'validated_head':release['source_identity']['head'],
 'incoming_main':'c19e544581aff37e9eff5a6a9976ccd78983b6e0',
 'integration_commit':'87705976019d4003e98ccfbae879c19e71c04d44',
 'snapshot_version':290,'rust_python_sources':1962,'unchanged_other_rust_python_files_from_full_run':1958,
 'single_critic':'../review/fresh-critic.md','repeat_critic':False,
 'runs':runs,
 'runtime':{key:proof[key] for key in ('status','classification','native_comparator','parity_certification',
    'source_identity','binary','map_source','profile','exact_steps','observations','stable_id',
    'first_limbo_step','first_unlimbo_step','move_issue_step','move_admitted_step','stop_issue_step',
    'stop_nav_cleared_step','stop_destination_changed','grounded_step','distinct_xy_after_move',
    'maximum_physical_z_after_move','sample_cost','discovery_prefix_exact_frames','gpu_frame','limits')},
 'preservation':{'old_records':111,'old_manifest_sha256':plan['old_manifest_sha256'],
    'old_manifest':'before/archive-sha256.json.gz','old_readme':'before/README.md.gz',
    'old_entries_exact_before_extension':True},
 'limits':['Full/clippy/Python preceded only four test-leaf repairs; all1958 other RS/PY files remain exact.',
           'Native corpus was rebound unchanged after main integration, not re-executed.',
           'Original critic ran once before incoming main; conflicts and test repairs were owner-validated.',
           'No whole native Save/Load, Unit AI, graphics/pixel or full movement parity certification.']}
target=DEST/'late-main/summary.json'
with target.open('x') as stream:json.dump(summary,stream,indent=2);stream.write('\n')
records['late-main/summary.json']={'archive_sha256':sha(target.read_bytes())}
assert not set(records).intersection(old)
combined=old|records
manifest_path.write_text(json.dumps(combined,indent=2)+'\n')
for relative,record in combined.items():
    assert sha((DEST/relative).read_bytes())==record['archive_sha256'],relative
assert all(sha((ROOT/rel).read_bytes())==digest for rel,digest in release['source_files'].items())
print(json.dumps({'added_records':len(records),'total_records':len(combined),
 'old111_exact':True,'all1962_rs_py_exact':True,'summary_sha256':records['late-main/summary.json']['archive_sha256']},indent=2))
