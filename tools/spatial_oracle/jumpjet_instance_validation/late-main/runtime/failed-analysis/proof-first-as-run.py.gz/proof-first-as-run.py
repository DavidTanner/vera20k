"""Revision of the sealed #689 one-off analysis for the fresh merged candidate.
End-frame production evidence only; no new gameplay/native publisher.
"""
from pathlib import Path
import hashlib
import json
from tools.cargo_run import source_identity, resolve_binary

ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load_run(name):
    directory = BASE / name
    report = json.loads((directory / 'run.json').read_text())
    capture = json.loads((directory / 'child-output/capture.json').read_text())
    assert report['status'] == 'VALID' and report['child']['exit_status'] == 0
    assert not report['child']['timed_out']
    return directory, report, capture

discovery, discovery_report, discovery_capture = load_run(
    'movement-target-689-late-main-jumpjet-discovery-20261003')
replay, replay_report, replay_capture = load_run(
    'movement-target-689-late-main-jumpjet-move-stop-20261003')
selection_path = BASE / 'movement-target-689-late-main-jumpjet-input-selection-20261003.json'
selection = json.loads(selection_path.read_text())
assert digest(discovery / 'child-output/capture.json') == selection['discovery_capture_sha256']
profile = json.loads((replay / 'profile.json').read_text())
assert digest(replay / 'profile.json') == selection['replay_profile_sha256']
move, stop = profile['commands'][-2:]
assert move == selection['move_command'] and stop == selection['stop_command']
stable_id = move['payload']['Move']['entity_id']
assert stop['payload']['Stop']['entity_id'] == stable_id == selection['stable_id']
move_step, stop_step = move['issue_after_step'], stop['issue_after_step']
offline_paths = [BASE / ('movement-target-689-late-main-jumpjet-' + label + '-offline-20261003.json')
                 for label in ('discovery', 'move-stop')]
for path in offline_paths:
    assert json.loads(path.read_text())['status'] == 'VALID'

frames = replay_capture['observations']['frames']
original_frames = discovery_capture['observations']['frames']
assert len(frames) == len(original_frames) == profile['ticks'] + 1 == 6001
assert replay_report['inputs']['executable'] == discovery_report['inputs']['executable']
assert replay_capture['map_source'] == discovery_capture['map_source']
assert replay_capture['initial'] == discovery_capture['initial']
assert replay_capture['observations']['commands'][:-2] == discovery_capture['observations']['commands']
compared_fields = ('actors', 'houses', 'completed_steps', 'simulation_tick',
                   'binary_frame', 'total_simulation_ms', 'missing_actor_ids')
for before, after in zip(original_frames[:move_step+1], frames[:move_step+1], strict=True):
    for field in compared_fields:
        assert before[field] == after[field], (before['completed_steps'], field)

samples = [(f['completed_steps'], a) for f in frames for a in f['actors']
           if a['type_id'] == 'SHAD']
assert {a['stable_id'] for _, a in samples} == {stable_id}
assert all(a['owner'] == move['owner'] for _, a in samples)
by_step = dict(samples)
first_live = next((step, actor) for step, actor in samples
                  if actor['active'] and not actor['in_limbo'])
before_move, after_move = by_step[move_step], by_step[move_step+1]
before_stop, after_stop = by_step[stop_step], by_step[stop_step+1]
assert not before_move['jumpjet']['moving']
assert before_move['radio']['dock_entered_with'] is None
assert after_move['jumpjet']['moving']
assert after_move['nav'] == {'Cell': {'rx': move['payload']['Move']['target_rx'],
                                    'ry': move['payload']['Move']['target_ry']}}
assert before_stop['jumpjet']['moving']
assert before_stop['radio']['dock_entered_with'] is None
assert after_stop['nav'] is None and after_stop['jumpjet']['moving']
assert after_stop['jumpjet']['destination_leptons'] != before_stop['jumpjet']['destination_leptons']

post_move = [(step, actor) for step, actor in samples if step > move_step]
grounded_step, grounded = next((step, actor) for step, actor in post_move
                              if step > stop_step and actor['jumpjet']['phase'] == 0
                              and not actor['jumpjet']['moving'])
air = grounded['foot']['air']
assert air['spatial_bucket'] is None
assert air['tracker_cell_560'] == air['slot_cell_564'] == [0, 0]
assert air['current_cell_slot_holder'] is None
assert air['tracker_cell_slot_holder'] is None
assert air['slot_cell_slot_holder'] is None
assert all(not actor['jumpjet']['moving'] and actor['jumpjet']['phase'] == 0
           for step, actor in samples if step >= grounded_step)
xy = {tuple(actor['physical_leptons'][:2]) for _, actor in post_move}
assert len(xy) > 1

transitions = []
previous = None
for step, actor in post_move:
    jj = actor['jumpjet']
    state = (jj['phase'], tuple(jj['destination_leptons']), jj['moving'],
             tuple(actor['foot']['air']['tracker_cell_560']),
             tuple(actor['foot']['air']['slot_cell_564']),
             actor['foot']['air']['spatial_bucket'],
             actor['foot']['air']['spatial_enter_order'])
    if state != previous:
        transitions.append({'step': step, 'xyz': actor['physical_leptons'],
                            'phase': jj['phase'], 'moving': jj['moving'],
                            'destination': jj['destination_leptons'],
                            'nav': actor['nav'], 'air': actor['foot']['air']})
        previous = state

source = source_identity(ROOT)
release_path = BASE / 'movement-target-689-final-release_game-r1-20261003.json'
release = json.loads(release_path.read_text())
assert release['cargo_run_exit'] == 0 and release['source_unchanged']
assert source == release['source_identity']
assert len(release['source_files']) == 1962
assert all(digest(ROOT / rel) == sha for rel, sha in release['source_files'].items())
binary_path, resolver_detail = resolve_binary(ROOT, 'vera20k', 'release')
assert binary_path is not None
assert digest(binary_path) == replay_report['inputs']['executable']['sha256']
sample_cost = sum(len(f['actors']) + sum(len((a.get('building') or {}).get('animation_slots') or [])
                  for a in f['actors']) + len(f['houses']) + len(f['missing_actor_ids'])
                  + len(f['terrain']) for f in frames)
assert sample_cost <= 100000

receipt = {
    'status': 'PASS', 'classification': 'bounded Rust release production witness',
    'native_comparator': 'NONE', 'parity_certification': 'NONE',
    'source_identity': source, 'exact_rust_python_sources': len(release['source_files']),
    'binary': replay_report['inputs']['executable'], 'binary_resolver': resolver_detail,
    'map_source': replay_capture['map_source'], 'profile': replay_report['inputs']['profile'],
    'exact_steps': profile['ticks'], 'observations': len(frames),
    'initial': replay_capture['initial'], 'final': replay_capture['final'],
    'stable_id': stable_id, 'first_limbo_step': samples[0][0],
    'first_unlimbo_step': first_live[0], 'move_issue_step': move_step,
    'move_admitted_step': move_step+1, 'stop_issue_step': stop_step,
    'stop_retained_destination_changed_step': stop_step+1,
    'stop_before': before_stop, 'stop_after': after_stop,
    'grounded_step': grounded_step, 'grounded_actor': grounded,
    'distinct_xy_after_move': len(xy),
    'maximum_physical_z_after_move': max(a['physical_leptons'][2] for _, a in post_move),
    'phase_cache_transitions': transitions, 'sample_cost': sample_cost,
    'discovery_prefix_exact_frames': move_step+1, 'compared_frame_fields': compared_fields,
    'terrain': frames[-1]['terrain'], 'gpu_frame': replay_capture['frame'],
    'files': {str(p): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in (
        replay / 'run.json', replay / 'child-output/capture.json', replay / 'child-output/frame.bgra',
        discovery / 'run.json', discovery / 'child-output/capture.json',
        release_path, selection_path, *offline_paths)},
    'limits': [
        'End-frame observations do not prove internal callback PCs/order or individual RNG draws.',
        'Single SHAD does not exercise a foreign occupied air-slot callback; composed native controls and Rust tests cover that branch.',
        'Terrain observations and supplied command cells are bounded Rust capture inputs; no native terrain admission equivalence is inferred.',
        'Prefix equality is limited to the declared observed actors/houses/clocks, not full-world per-frame hashes.',
        'Historical cff captures and failed diagnostic-budget bundles remain separate evidence.']}
out = BASE / 'movement-target-689-jumpjet-late-main-runtime-proof-20261003.json'
with out.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: receipt[k] for k in ('status', 'exact_steps', 'observations', 'stable_id',
      'grounded_step', 'distinct_xy_after_move', 'maximum_physical_z_after_move',
      'sample_cost', 'exact_rust_python_sources')}, indent=2))
print('receipt', out, digest(out))
