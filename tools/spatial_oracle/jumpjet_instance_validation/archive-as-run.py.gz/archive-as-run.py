"""One-off byte-preserving evidence archive, not a new native publisher."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil


ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
DEST = ROOT / 'tools/spatial_oracle/jumpjet_instance_validation'
assert not DEST.exists()
DEST.mkdir()
records = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve(source, relative, compressed=True):
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    data = source.read_bytes()
    if compressed:
        with target.open('xb') as stream:
            with gzip.GzipFile(filename='', fileobj=stream, mode='wb', compresslevel=9, mtime=0) as archive:
                archive.write(data)
        assert gzip.decompress(target.read_bytes()) == data
    else:
        with target.open('xb') as stream:
            stream.write(data)
    assert source.read_bytes() == data
    records[relative] = {'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                         'archive_bytes': target.stat().st_size,
                         'archive_sha256': sha(target.read_bytes()), 'gzip': compressed}


runs = (
    ('focused-g5', 'movement-target-689-regression-green-g5-20261003'),
    ('primary63', 'movement-target-689-final-primary63-r0-20261003'),
    ('full', 'movement-target-689-final-full_lib-r0-20261003'),
    ('clippy', 'movement-target-689-final-clippy_lib-r0-20261003'),
    ('release', 'movement-target-689-final-release_game-r0-20261003'),
    ('python', 'movement-target-689-final-python_suite-p1-20261003'))
summary = {'classification': 'bounded native comparisons and Rust regression/production validation',
           'validated_head': 'cff0947c329f25947c7eeba1056ff5d94d31375e',
           'incoming_main': 'cf4317b334', 'runs': [], 'native': {}, 'runtime': {}}
for label, stem in runs:
    receipt = json.loads((BASE / f'{stem}.json').read_text())
    assert receipt['cargo_run_exit'] == 0 and receipt['source_unchanged']
    assert sha((BASE / f'{stem}.log').read_bytes()) == receipt['log_sha256']
    preserve(BASE / f'{stem}.json', f'checks/{label}-receipt.json.gz')
    preserve(BASE / f'{stem}.log', f'checks/{label}.log.gz')
    summary['runs'].append({key: receipt.get(key) for key in (
        'mode', 'argv', 'cargo_run_exit', 'wall_seconds', 'source_identity',
        'test_summaries', 'fixture_skip_marker', 'log_sha256')} | {'label': label})
preserve(BASE / 'movement-target-689-measure-red-20261003.py', 'checks/measurement-as-run.py.gz')
preserve(BASE / 'movement-target-689-final-validation-invocation-plan-20261003.json', 'checks/invocation-plan.json', False)
preserve(BASE / 'movement-target-689-final-field-ratchet-cff-20261003.txt', 'checks/field-ratchet.txt', False)

for tag in ('red-r0', 'red-r1', 'green-g1', 'green-g3', 'green-g4'):
    stem = f'movement-target-689-regression-{tag}-20261003'
    for extension in ('json', 'log'):
        preserve(BASE / f'{stem}.{extension}', f'regression/{tag}.{extension}.gz')

for version in ('v3', 'v4', 'v5'):
    source_dir = BASE / f'movement-target-689-native-publication-{version}-20261003'
    for source in sorted(source_dir.rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(source_dir).as_posix()
        if version == 'v5' and relative.startswith('published.'):
            continue  # The six active artifacts already have their unique owner beside this archive.
        compressed = source.suffix != '.gz'
        preserve(source, f'native/{version}/{relative}' + ('.gz' if compressed else ''), compressed)
native = json.loads((BASE / 'movement-target-689-native-publication-v5-20261003/completion-receipt.json').read_text())
summary['native'] = {key: native[key] for key in (
    'counts', 'old15_projected_exact', 'old15_raw_exact', 'legacy10_exact',
    'raw_uncompressed', 'scenario_seed0_control', 'limits')}

for label, stem in (
    ('discovery', 'movement-target-689-jumpjet-instance-discovery-20261003'),
    ('failed-budget-r0', 'movement-target-689-jumpjet-instance-move-stop-20261003'),
    ('failed-budget-r1', 'movement-target-689-jumpjet-instance-move-stop-r1-20261003'),
    ('move-stop', 'movement-target-689-jumpjet-instance-move-stop-r2-20261003')):
    source_dir = BASE / stem
    for source in sorted(source_dir.rglob('*')):
        if not source.is_file() or source.name == 'config.toml':
            continue
        relative = source.relative_to(source_dir).as_posix()
        preserve(source, f'runtime/{label}/{relative}' + ('' if source.name == 'profile.json' else '.gz'),
                 source.name != 'profile.json')
for label, source in (
    ('discovery-offline.json.gz', 'movement-target-689-jumpjet-instance-discovery-offline-20261003.json'),
    ('move-stop-offline.json.gz', 'movement-target-689-jumpjet-instance-move-stop-r2-offline-20261003.json'),
    ('proof.json', 'movement-target-689-jumpjet-instance-runtime-proof-20261003.json'),
    ('proof-as-run.py.gz', 'movement-target-689-runtime-proof-20261003.py'),
    ('input-selection.json', 'movement-target-689-jumpjet-instance-discovery-input-selection-20261003.json'),
    ('move-stop-view.png', 'movement-target-689-jumpjet-instance-move-stop-r2-view-20261003.png')):
    preserve(BASE / source, f'runtime/{label}', label.endswith('.gz'))
proof = json.loads((BASE / 'movement-target-689-jumpjet-instance-runtime-proof-20261003.json').read_text())
summary['runtime'] = {key: proof[key] for key in (
    'status', 'classification', 'native_comparator', 'parity_certification', 'source_identity',
    'exact_rust_python_sources', 'binary', 'map_source', 'profile', 'exact_steps', 'observations',
    'stable_id', 'first_limbo_step', 'first_unlimbo_step', 'move_issue_step', 'move_admitted_step',
    'stop_issue_step', 'stop_retained_destination_changed_step', 'grounded_step',
    'distinct_xy_after_move', 'maximum_physical_z_after_move', 'sample_cost',
    'discovery_prefix_exact_frames', 'partial_retry_exact_frames', 'gpu_frame', 'limits')}
with (DEST / 'summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
records['summary.json'] = {'archive_sha256': sha((DEST / 'summary.json').read_bytes())}
with (DEST / 'archive-sha256.json').open('x') as stream:
    json.dump(records, stream, indent=2)
    stream.write('\n')
print(json.dumps({'archive': str(DEST), 'files': len(records),
                  'total_archive_bytes': sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file()),
                  'summary_sha256': records['summary.json']['archive_sha256']}, indent=2))
