"""One-off analysis of sealed #689 captures; no gameplay/schema implementation."""
from pathlib import Path
import hashlib
import json

from tools.cargo_run import source_identity


ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_run(name):
    directory = BASE / name
    report = json.loads((directory / 'run.json').read_text())
    manifest = json.loads((directory / 'child-output/capture.json').read_text())
    return directory, report, manifest


discovery, discovery_report, discovery_capture = load_run(
    'movement-target-689-jumpjet-instance-discovery-20261003')
replay, replay_report, replay_capture = load_run(
    'movement-target-689-jumpjet-instance-move-stop-r2-20261003')
partial, partial_report, partial_capture = load_run(
    'movement-target-689-jumpjet-instance-move-stop-r1-20261003')
for report in (discovery_report, replay_report):
    assert report['status'] == 'VALID'
    assert report['child']['exit_status'] == 0
    assert not report['child']['timed_out']
for name in ('movement-target-689-jumpjet-instance-discovery-offline-20261003.json',
             'movement-target-689-jumpjet-instance-move-stop-r2-offline-20261003.json'):
    assert json.loads((BASE / name).read_text())['status'] == 'VALID'

frames = replay_capture['observations']['frames']
original_frames = discovery_capture['observations']['frames']
partial_frames = partial_capture['observations']['frames']
assert len(frames) == len(original_frames) == 6001
assert len(partial_frames) == 5998
assert replay_report['inputs']['executable'] == discovery_report['inputs']['executable']
assert replay_capture['map_source'] == discovery_capture['map_source']
assert replay_capture['initial'] == discovery_capture['initial']
assert replay_capture['observations']['commands'][:10] == discovery_capture['observations']['commands']

compared_fields = ('actors', 'houses', 'completed_steps', 'simulation_tick',
                   'binary_frame', 'total_simulation_ms', 'missing_actor_ids')
for before, after in zip(original_frames[:5601], frames[:5601], strict=True):
    for field in compared_fields:
        assert before[field] == after[field], (before['completed_steps'], field)
for before, after in zip(partial_frames, frames[:5998], strict=True):
    for field in compared_fields:
        assert before[field] == after[field], (before['completed_steps'], field)

samples = [(f['completed_steps'], a) for f in frames for a in f['actors']
           if a['type_id'] == 'SHAD']
assert {a['stable_id'] for _, a in samples} == {1528}
assert all(a['owner'] == 'VERA-OBSERVER' for _, a in samples)
by_step = dict(samples)
first_live = next((step, actor) for step, actor in samples
                  if actor['active'] and not actor['in_limbo'])
assert first_live[0] == 5195
before_move, after_move = by_step[5600], by_step[5601]
before_stop, after_stop = by_step[5620], by_step[5621]
assert not before_move['jumpjet']['moving']
assert before_move['radio']['dock_entered_with'] is None
assert after_move['jumpjet']['moving']
assert after_move['nav'] == {'Cell': {'rx': 30, 'ry': 93}}
assert after_move['jumpjet']['destination_leptons'] == [7808, 23936, 416]
assert before_stop['jumpjet']['phase'] == 1
assert before_stop['jumpjet']['moving']
assert before_stop['radio']['dock_entered_with'] is None
assert after_stop['nav'] is None
assert after_stop['jumpjet']['destination_leptons'] == [8320, 23936, 416]
assert after_stop['jumpjet']['moving']

post_move = [(step, actor) for step, actor in samples if step > 5600]
grounded_step, grounded = next((step, actor) for step, actor in post_move
                              if step > 5620 and actor['jumpjet']['phase'] == 0
                              and not actor['jumpjet']['moving'])
air = grounded['foot']['air']
assert grounded['physical_leptons'] == [8320, 23936, 416]
assert air['spatial_bucket'] is None
assert air['tracker_cell_560'] == air['slot_cell_564'] == [0, 0]
assert air['current_cell_slot_holder'] is None
assert air['tracker_cell_slot_holder'] is None
assert air['slot_cell_slot_holder'] is None
assert all(not actor['jumpjet']['moving'] and actor['jumpjet']['phase'] == 0
           for step, actor in samples if step >= grounded_step)
xy = {tuple(actor['physical_leptons'][:2]) for _, actor in post_move}
assert len(xy) > 1

transitions = []
previous = None
for step, actor in post_move:
    jj = actor['jumpjet']
    state = (jj['phase'], tuple(jj['destination_leptons']), jj['moving'],
             tuple(actor['foot']['air']['tracker_cell_560']),
             tuple(actor['foot']['air']['slot_cell_564']),
             actor['foot']['air']['spatial_bucket'],
             actor['foot']['air']['spatial_enter_order'])
    if state != previous:
        transitions.append({'step': step, 'xyz': actor['physical_leptons'],
                            'phase': jj['phase'], 'moving': jj['moving'],
                            'destination': jj['destination_leptons'],
                            'nav': actor['nav'], 'air': actor['foot']['air']})
        previous = state

source = source_identity(ROOT)
release = json.loads((BASE / 'movement-target-689-final-release_game-r0-20261003.json').read_text())
assert source == release['source_identity']
assert all(digest(ROOT / rel) == sha for rel, sha in release['source_files'].items())
sample_cost = sum(len(f['actors']) + sum(len((a.get('building') or {}).get('animation_slots') or [])
                  for a in f['actors']) + len(f['houses']) + len(f['missing_actor_ids'])
                  + len(f['terrain']) for f in frames)
assert sample_cost == 70053

receipt = {
    'status': 'PASS', 'classification': 'bounded Rust release production witness',
    'native_comparator': 'NONE', 'parity_certification': 'NONE',
    'source_identity': source, 'exact_rust_python_sources': len(release['source_files']),
    'binary': replay_report['inputs']['executable'], 'map_source': replay_capture['map_source'],
    'profile': replay_report['inputs']['profile'], 'exact_steps': 6000, 'observations': len(frames),
    'initial': replay_capture['initial'], 'final': replay_capture['final'],
    'stable_id': 1528, 'first_limbo_step': samples[0][0], 'first_unlimbo_step': first_live[0],
    'move_issue_step': 5600, 'move_admitted_step': 5601,
    'stop_issue_step': 5620, 'stop_retained_destination_changed_step': 5621,
    'stop_before': before_stop, 'stop_after': after_stop,
    'grounded_step': grounded_step, 'grounded_actor': grounded,
    'distinct_xy_after_move': len(xy), 'maximum_physical_z_after_move': max(a['physical_leptons'][2] for _, a in post_move),
    'phase_cache_transitions': transitions, 'sample_cost': sample_cost,
    'discovery_prefix_exact_frames': 5601, 'partial_retry_exact_frames': 5998,
    'compared_frame_fields': compared_fields,
    'terrain': frames[-1]['terrain'], 'gpu_frame': replay_capture['frame'],
    'files': {str(p): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in (
        replay / 'run.json', replay / 'child-output/capture.json', replay / 'child-output/frame.bgra',
        discovery / 'run.json', discovery / 'child-output/capture.json',
        BASE / 'movement-target-689-jumpjet-instance-discovery-offline-20261003.json',
        BASE / 'movement-target-689-jumpjet-instance-move-stop-r2-offline-20261003.json')},
    'limits': [
        'End-frame observations do not prove internal callback PCs/order or individual RNG draws.',
        'Single SHAD does not exercise a foreign occupied air-slot callback; composed native controls and Rust tests cover that branch.',
        'Terrain probes report slope0/level4/no bridge and walkable=false; no Clear land-type or native terrain admission equivalence is inferred.',
        'Failed r0/r1 diagnostic bundles hit the existing sample budget; they are not VALID/GPU evidence.',
        'Prefix equality is limited to the declared observed actors/houses/clocks, not full-world per-frame hashes.']}
out = BASE / 'movement-target-689-jumpjet-instance-runtime-proof-20261003.json'
with out.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: receipt[k] for k in ('status', 'exact_steps', 'observations', 'grounded_step',
      'distinct_xy_after_move', 'maximum_physical_z_after_move', 'sample_cost', 'exact_rust_python_sources')}, indent=2))
print('receipt', out, digest(out))
