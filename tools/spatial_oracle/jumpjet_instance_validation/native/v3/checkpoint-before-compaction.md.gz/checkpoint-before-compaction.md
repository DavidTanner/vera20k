# #689 native owner checkpoint — 2026-10-03

Owned worktree: `/Users/halvor/Documents/vera20k-worktrees/vera20k-height`, branch `feature/jumpjet-synchronous-scatter`, base `7e932b968e9b901142d80944095af68fe178ebdc`. Root owns Rust, Cargo/game, Git/issues and PR publication. This owner owns only existing Python native fixture/instrumentation owners and their evidence.

## Current handoff

**Native lane released; all owned tracked files frozen.** No VM/Cargo/game remains on this owner. Existing `jumpjet_states --write` and independent `--check` both completed actual0. Existing `cmin_dock --check` completed actual0 with unchanged payload and metadata. Root may run the first Rust regression failure measurement. No more tracked edits/native execution until explicit new lane handoff.

Schema2 contains exact legacy10 and15 additive controls:375 steps,2813 boundaries,2555 matched calls,10 raw draws. Original binary SHA256 `1cdd1180e49024fbda8ad568caac2e86e856063ff67ab38f62b7d2c7bb84298c`. Corpus file SHA256 `c6934aafe7130e97beb17e80fe882e1bebfddea2bd41a797b444698eee911f33`; canonical payload SHA256 `7426193c02e7f68d27ec4e88f97437a1bbb6729ce2f896ad1fc0882e23519965`; metadata SHA256 `32bb648c11cb3df29b345f5a1a09c16350d5e1412004a11733f0fa21ae1848bd`; producer SHA256 `ae779ad54276e0d5d44fad613fd956d7ffc322067b2f48d3d26b762bed357e1a`. Metadata pins23 executing local Python sources; it does not bind concurrent Rust preparation.

Terminal, scalar/call/RNG equality, CMIN and18-file freeze receipts are under `movement-target-689-native-publication-v2-20261003/`. CMIN's50 old rows and whole payload/meta are byte-identical:13 steps/121 boundaries/97 matched instance calls. CMIN file SHA256 remains `29f085a9e0f173b98f8a5ac2dd8d4b161a9c447cfe67d6c4305e09957f779677`.

## Established selected behavior

Actual ordinary stock SHAD Cell order runs Unit741970 -> Foot4D94B0 -> Jumpjet54B1C0 with original FNPC56DC20/56E7C0 and Process54AEC0 through trueRET54B199. Physical selected original ctor/read/link inputs match the independent production SHAD report; Rust values never initialize native memory. Both free/taken State1 run Mark0/save/restore/+74/phase suffixes. State3 controls prove live post-setter destination LandType use; relevant gates/State4/Stop/arrival are executed. All13 previously saved r8 behavioral histories retain exact full Foot/JJ/RNG/cell state and their old observed call/draw traces; additional observations expose SetZ/+F0/+F4/State2 without altering execution.

Frame151 occupied path: before XYZ3198,2688,490/destination3712,2688,0/phase1/Nav14,10/movement timer100,0/blocked100,60; after XYZ3228,2688,500/destination3456,2944,0/phase3/Nav13,11/timers151,0 and151,60. Marked1 and caches560=(12,10),564=Null remain. Exactly one Scenario raw draw changes indices0,103 ->1,104; full Main/Mapgen unchanged. The following visit uses the new destination.

Native tracker560 and remembered slot564 are separate. Within-bucket Cell crossings write560 without removing/appending order. Cell487D70 release notifies the old Foot before raw E0 clear; claim raw-writes E0 then concrete Foot4E00B0, which directly clears an old matching slot. Same-owner claim therefore succeeds but clears E0 and retains564. Ordinary arrival/Stop clear both caches and execute occupation+F0/+F4. SetZ5F6060 writes only+A4 with actual Mark0/Mark1 when marked, without FootSetLocation/rider callbacks.

Whole active-game UnInit4DE5D0 performs Limbo/expiry/deferred append, clears560/Mark and retains564/ownE0. The explicit later selected Foot destructor XOR4D3595/cache4D3632..4D366E clears ownedE0 directly; obsolete564 remains. This is not whole destructor/deferred-drain proof. `movement-target-689-native-uninit-r13-20261003/history.json` SHA256 `60d268bc01d2095bf41ba1595fd065437f25266a98cbe43bd60d3c3283cf6223` retains that execution.

## Ownership and limits

Freeze manifest names all15 Python files plus JSON/meta/focused owner doc. Shared NativeCallTrace/byte-span/platform transport have one existing native_oracle owner; CMIN delegates unchanged. Unit fixture owners accept same-VM storage; Mark/discovery, FNPC plane, tracker/display and GUID transport reuse existing owners. No new port/controller/generator, Rust edit or Git mutation was introduced.

Current corpus is95,226,695 bytes. Root requested deterministic gzip archival preserving all full raw evidence byte-for-byte, with a smaller native-derived Rust projection of inputs/steps/before-after/full asserted RNG. **That edit waits until after first RED and a new source lane.** r0/r1/r3/r5/r6/r7/r8/r9-r13 failures/partials/actual receipts remain immutable. Do not overwrite them during compaction.

Selected reader regions do not prove full native type/ART/scenario loading; world/map/foreign Unit inputs are supplied recorded premises. Ordinary Process GameActive0 and separate retirement GameActive1 are explicit. Supplemental retained handlers are not whole mission/AI reachability. Full destructor/drain, State5 crash, bridge/building-top and full scenario remain outside the claim. New native behavior is established; Rust regression/parity awaits root's implementation and actual validation. Shared fixture legacy checks beyond old10/CMIN may run in the next authorized lane before final delivery.
