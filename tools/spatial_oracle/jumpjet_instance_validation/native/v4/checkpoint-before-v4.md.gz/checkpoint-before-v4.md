# #689 native owner checkpoint — 2026-10-03

Owned worktree: `/Users/halvor/Documents/vera20k-worktrees/vera20k-height`, branch `feature/jumpjet-synchronous-scatter`, base `7e932b968e9b901142d80944095af68fe178ebdc`. Root owns Rust, Cargo/game, Git/issues and PR publication. This owner owns existing Python native fixture/instrumentation owners and evidence only.

## Current handoff

**All 20 owned files frozen; native lane released.** Existing Jumpjet `--write` and independent `--check` both completed actual 0. Existing CMIN `--check` completed actual 0. No native/Cargo/game process remains on this owner. Root may validate the corrected Rust chain; no further tracked edits or native execution until an explicit handoff.

`movement-target-689-native-publication-v3-20261003/terminal-receipt.json`, its three logs, `scalar-receipt.json` and `freeze-manifest.json` record actual completion. Receipt summary scripts initially used wrong schema keys after the three successful child commands; their failures are retained and were corrected without replay or source/data mutation. Previous v2/r8/r13 and all failed/partial native histories remain immutable.

The expected projection is 13,723,255 bytes, file SHA256 `a29f8471ef75e36ee28fcaadab0c779b9e9a9c5f2dbbf80e71704128a492d646`, canonical payload SHA256 `33da979682e4623ef479efe9554e57e321d8289afdcbf1fb9b47bf007ecadbea`, metadata SHA256 `9054da9448c489199945a57f911d4c67e4d77622dd219dc38b6d897b60a5bea7`. The sole publisher archives the complete accepted raw corpus as deterministic gzip: 1,030,722 bytes, SHA256 `1e632969abee71e23236c772cac0765e378b913a265e5b8a0615b17c71f12c68`. Decompression is exactly 95,226,695 bytes, SHA256 `c6934aafe7130e97beb17e80fe882e1bebfddea2bd41a797b444698eee911f33`; raw canonical payload SHA256 remains `7426193c02e7f68d27ec4e88f97437a1bbb6729ce2f896ad1fc0882e23519965`. Archive metadata SHA256 `20bf03b811a094b30a28f62286b8eb1fad91909027e9e7006c5e3f1f8e596799` records binary, source, compression and coverage. Gzip level 9/MTIME 0/empty filename/OS byte 255 uses zlib 1.2.12.

All ten legacy rows and fifteen controls are retained. All 375 steps retain before/after scalar state and full Main/Scenario/Mapgen RNG strings: 750 expected boundaries. Remapped `steps.before/after` index that array; each `raw_boundary_index` identifies its original archive row. The archive keeps all 2,813 raw boundaries, 2,555 matched calls and ten raw draws, with full Foot/Jumpjet/world/class/queue/list/occupation storage and code/guard/FPCW checks. Call/write/draw receipts are unchanged. Native pointer decoding adds logical cell/tracker order, foreign fixture fields, TarCom, arguments and supplied inputs without creating gameplay results.

Producer SHA256 `11cc52b82138664fe26e50524b4025867dbaaf9e6d89ad06f22851037f9a3310` and shared publisher SHA256 `aa03852ed722fabf2bbba45b1f11f41aec6fcaf7168c8415fb39efc2183a6b82` bind 23 executing local Python owners. The Rust native-reader leaf is independently frozen at `3572259a9e4c21cdfdbbee111d73eb376e1078c32152780a4711dc824f0fd90b`; concurrent Rust preparation is outside Python source pins. Root owns final Rust source binding.

CMIN's old 50 rows and entire payload/metadata remain byte-identical. Its three histories still contain 13 steps, 121 boundaries and 97 matched calls. Payload SHA256 `29f085a9e0f173b98f8a5ac2dd8d4b161a9c447cfe67d6c4305e09957f779677`; metadata SHA256 `d6b99dea87ddb48fd7d25bc687b38165421edfa28b413a5dd102e488b4db70f3`. No unrelated native corpus or sidecar changed.

## Established selected behavior

Original binary SHA256 `1cdd1180e49024fbda8ad568caac2e86e856063ff67ab38f62b7d2c7bb84298c` and .text SHA256 `4cd5557a7490debc493ff965afc4483d8d2f1065f434f6b665cbb8fc4835b0cc`. Ordinary selected-reader-bound stock SHAD Cell order executes Unit741970 -> Foot4D94B0 -> Jumpjet54B1C0, actual FNPC and Process54AEC0 through trueRET54B199. Frame 151 occupied State1 changes destination from `[3712,2688,0]` to `[3456,2944,0]` in the same update, with new NavCom `[13,11]`, timers `[151,0]`/`[151,60]` and one Scenario draw. Both free/taken Mark/save/restore/phase suffixes and following Translate are retained. Root recorded the causal Rust RED before behavior edits.

Distinct +560 tracker and +564 slot caches, within-bucket crossing/order, foreign refusal/replacement/release/same-owner quirk, real SetZ/occupation, Stop/arrival, State3 live destination and selected State4 controls remain established. Whole active-game UnInit retains +564/own E0 after clearing tracker/Mark; the selected destructor cache block later clears owned E0 directly without notification or clearing obsolete +564. The selected block is not whole destructor/deferred-drain proof.

Static State2 same-position ordering is recorded near the corpus owner, including TarCom early return, simple-deployer/balloon Mark/restore/phase2 arms, owned-current-slot release/phase4 arms and absence of a State2 latch write. Stock false flags keep those deployer/balloon arms instruction-order evidence; no new VM control was added for them.

## Limits and next safe action

Physical native ctor/selected INI readers are independent of the production SHAD comparison report. Coverage does not include full type/ART/scenario loading; the 32x32 flat world, foreign Unit and ordinary GameActive 0 are supplied premises. Supplemental retained handlers are not whole mission/AI reachability. Whole destructor/drain, State5 crash, bridge/building-top and full scenario remain outside the claim. Native selected behavior is established; root owns Rust tests/parity and complete-chain validation. Stay frozen while Cargo runs.
