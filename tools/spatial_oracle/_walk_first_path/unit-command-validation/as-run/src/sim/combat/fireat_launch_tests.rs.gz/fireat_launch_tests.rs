//! Production frames for FireAt's launch geometry on retail rules and art:
//! the launch speed (`WeaponTypeClass::GetSpeed @ 0x00773070`) from the
//! barrel's FLH, and the moving-target lead (`0x0070BCB0`). Skipped without
//! the retail `ini/rulesmd.ini` and `ini/artmd.ini`.

use crate::rules::ruleset::RuleSet;
use crate::sim::command::{Command, CommandEnvelope};
use crate::sim::projectile::{ProjectileCoord, launch::fireat_launch_distance};
use crate::sim::world::Simulation;

#[test]
fn grand_cannon_recoil_follows_successful_launch_ai_and_snapshot() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    let cannon = duel.spawn("GTGCAN", "Americans", 20, 20, 64);
    duel.spawn("GAPOWR", "Americans", 8, 8, 0);
    duel.spawn("GAPOWR", "Americans", 12, 8, 0);
    // Production scenario loading binds handles after constructing its roster.
    // Building direction-to-target consumes that registry, unlike Unit fire.
    duel.sim.resolve_type_handles(&duel.rules);
    // A real inadmissible shot must not arm the presentation component.
    duel.order(
        "Americans",
        Command::ForceAttackCell {
            attacker_id: cannon,
            target_rx: 2,
            target_ry: 2,
        },
    );
    for _ in 0..60 {
        duel.tick();
        assert!(duel.launched_by(cannon).is_none());
        assert_eq!(
            duel.sim
                .substrate
                .entities
                .get(cannon)
                .unwrap()
                .voxel_recoil(),
            ([0.0; 2], false)
        );
    }
    duel.order(
        "Americans",
        Command::ForceAttackCell {
            attacker_id: cannon,
            target_rx: 20,
            target_ry: 30,
        },
    );
    let mut fired = false;
    for _ in 0..240 {
        duel.tick();
        if duel.launched_by(cannon).is_some() {
            fired = true;
            break;
        }
    }
    let actor = duel.sim.substrate.entities.get(cannon).unwrap();
    let fire_error = super::fire_error_world::FireSubject {
        world: &duel.sim,
        rules: &duel.rules,
        overlay_registry: None,
        fog: None,
        firer: actor,
        obj: duel.rules.object("GTGCAN").unwrap(),
        target: actor.attack_target.as_ref().map(|a| a.target),
        weapon_index: 0,
        garrison: None,
    }
    .fire_error(true);
    assert!(
        fired,
        "retail cannon launch: error={fire_error:?}, mission={:?}, target={:?}, last_fire={}, actually_placed={}, body={:?}, facing={:?}",
        actor.mission,
        actor.attack_target,
        actor.last_fire_frame,
        actor.building_actually_placed,
        actor.building_body_state(),
        actor.body_facing
    );
    assert_eq!(
        duel.sim
            .substrate
            .entities
            .get(cannon)
            .unwrap()
            .voxel_recoil(),
        ([0.0; 2], true),
        "FireAt arms after this visit's Techno AI"
    );
    for _ in 0..3 {
        duel.tick();
    }
    assert_eq!(
        duel.sim
            .substrate
            .entities
            .get(cannon)
            .unwrap()
            .voxel_recoil(),
        ([0.0, 8.0], true)
    );

    let terrain = duel.sim.resolved_terrain.as_ref().unwrap().clone();
    let bytes = crate::sim::snapshot::GameSnapshot::save(&duel.sim, 0, 0, "recoil", 0);
    let mut restored = crate::sim::snapshot::GameSnapshot::load(&bytes)
        .unwrap()
        .sim;
    restored.restore_after_snapshot_load().unwrap();
    restored.resolve_type_handles(&duel.rules);
    restored.install_resolved_terrain_for_new_map(terrain);
    assert!(restored.rebuild_dynamic_navigation(&duel.rules));
    assert_eq!(
        restored
            .substrate
            .entities
            .get(cannon)
            .unwrap()
            .voxel_recoil(),
        ([0.0, 8.0], true)
    );
    for _ in 3..46 {
        duel.tick();
        let commands = restored.take_due_commands();
        restored.advance_tick(&commands, Some(&duel.rules), Some(&duel.grid), None, 67);
        assert_eq!(
            restored
                .substrate
                .entities
                .get(cannon)
                .unwrap()
                .voxel_recoil(),
            duel.sim
                .substrate
                .entities
                .get(cannon)
                .unwrap()
                .voxel_recoil()
        );
    }
    assert_eq!(
        duel.sim
            .substrate
            .entities
            .get(cannon)
            .unwrap()
            .voxel_recoil(),
        ([0.0; 2], false),
        "original stock cycle ends after46 AI updates"
    );
}

#[test]
fn grand_cannon_recoil_state_cannot_change_simulation_hash_or_rng() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    let cannon = duel.spawn("GTGCAN", "Americans", 20, 20, 64);
    let hash = duel.sim.state_hash();
    let rng = duel.sim.scenario_rng.logical_state();
    let entity = duel.sim.substrate.entities.get_mut(cannon).unwrap();
    entity.fire_voxel_recoil(true);
    entity.update_voxel_recoil();
    assert!(entity.voxel_recoil().1);
    assert_eq!(duel.sim.state_hash(), hash);
    assert_eq!(duel.sim.scenario_rng.logical_state(), rng);
}

struct Duel {
    sim: Simulation,
    rules: RuleSet,
    grid: crate::sim::pathfinding::PathGrid,
    /// Projectiles alive before the latest tick.
    before: std::collections::BTreeSet<u64>,
}

impl Duel {
    fn new() -> Option<Self> {
        let ini = crate::rules::retail_ini_fixture::retail_ini("rulesmd.ini")?;
        let art = crate::rules::retail_ini_fixture::retail_ini("artmd.ini")?;
        let mut rules =
            RuleSet::from_ini_with_fixed_art_for_test(&ini, &art).expect("retail rules parse");
        rules.install_art_data(crate::rules::art_data::ArtRegistry::from_ini(&art));
        let mut sim = Simulation::new();
        for (name, side, human) in [("Americans", 0, true), ("Russians", 1, true)] {
            let id = sim.interner.intern(name);
            sim.houses.insert(
                id,
                crate::sim::house_state::HouseState::new(id, side, None, human, 0, 10),
            );
            sim.session.house_order.push(id);
        }
        let grid = crate::sim::arena_fixture::flat_arena(&mut sim, &rules);
        // Production binds every rule identity before building the derived
        // type table. A table built with only House IDs cannot resolve types
        // interned by later spawns, including destination preflight inputs.
        sim.intern_rule_type_ids(&rules);
        sim.resolve_type_handles(&rules);
        Some(Self {
            sim,
            rules,
            grid,
            before: std::collections::BTreeSet::new(),
        })
    }

    fn spawn(&mut self, kind: &str, owner: &str, rx: u16, ry: u16, facing: u8) -> u64 {
        let id = self
            .sim
            .spawn_object(kind, owner, rx, ry, facing, &self.rules)
            .unwrap_or_else(|| panic!("spawn {kind}"));
        assert!(
            self.sim
                .object_type(self.sim.entities().get(id).unwrap().type_ref(), &self.rules)
                .is_some(),
            "spawned {kind} must have a bound production type identity"
        );
        id
    }

    fn order(&mut self, owner: &str, command: Command) {
        let owner = self.sim.interner.intern(owner);
        self.sim.queue_command(CommandEnvelope::new(
            owner,
            self.sim.session.tick + 1,
            command,
        ));
    }

    fn tick(&mut self) {
        self.sim.fire_events.clear();
        self.before = self.sim.projectiles.iter().map(|(&id, _)| id).collect();
        let commands = self.sim.take_due_commands();
        self.sim
            .advance_tick(&commands, Some(&self.rules), Some(&self.grid), None, 67);
    }

    fn health(&self, id: u64) -> i32 {
        self.sim
            .substrate
            .entities
            .get(id)
            .map_or(0, |entity| i32::from(entity.health.current))
    }

    fn location(&self, id: u64) -> ProjectileCoord {
        let entity = self.sim.substrate.entities.get(id).unwrap();
        ProjectileCoord::new(
            i32::from(entity.position.rx) * 256 + entity.position.sub_x.to_num::<i32>(),
            i32::from(entity.position.ry) * 256 + entity.position.sub_y.to_num::<i32>(),
            crate::sim::movement::ground_pose::object_world_z_leptons(
                entity,
                self.sim.resolved_terrain.as_ref(),
            ),
        )
    }

    fn actor_state(&self, id: u64) -> String {
        let Some(actor) = self.sim.substrate.entities.get(id) else {
            return format!("{id}: retired");
        };
        format!(
            "{id}: location={:?}, health={}, mission={:?}, target={:?}, nav={:?}, moving={:?}, fraction={:?}, adapter={}, last_fire={}",
            self.location(id),
            actor.health.current,
            actor.mission,
            actor.attack_target,
            actor.navigation.nav_com,
            crate::sim::movement::motion_query::is_moving(actor),
            actor.foot_speed.applied_fraction(),
            actor.movement_target.is_some(),
            actor.last_fire_frame,
        )
    }

    /// The first shell the firer launched this frame, if any. It has already
    /// taken its first AI step in the frame's tail, so it is recognised as
    /// new rather than by standing on its launch origin.
    fn launched_by(&self, firer: u64) -> Option<&crate::sim::projectile::Projectile> {
        self.sim
            .projectiles
            .iter()
            .map(|(_, projectile)| projectile)
            .find(|projectile| {
                projectile.source_id == firer && !self.before.contains(&projectile.id)
            })
    }
}

/// Retail data the regression rests on: the Grizzly's `[105mm]` fires
/// `[Cannon]`, an `Arcing=` projectile, at `Speed=40` under `Gravity=6`.
#[test]
fn retail_cannon_uses_converted_speed_and_arcing_under_gravity_6() {
    let Some(ini) = crate::rules::retail_ini_fixture::retail_ini("rulesmd.ini") else {
        return;
    };
    let rules = RuleSet::from_ini(&ini).unwrap();
    assert_eq!(rules.general.gravity, 6);
    for (tank, weapon) in [("MTNK", "105mm"), ("HTNK", "120mm")] {
        let object = rules.object(tank).unwrap();
        assert_eq!(object.primary.as_deref(), Some(weapon), "{tank}");
        // The raw reader converts authored40 to102; ROT0's later postpass
        // replaces it using prior Gravity. That ordered state is compared to
        // original full Process in rules::native_processing::weapon_speed_tests.
        assert_eq!(ini.section(weapon).unwrap().read_speed("Speed", 0), 102);
        let weapon = rules.weapon(weapon).unwrap();
        let projectile = rules
            .projectile(weapon.projectile.as_deref().unwrap())
            .unwrap();
        assert!(projectile.arcing && projectile.rot == 0, "{tank}");
    }
}

/// A Grizzly engaging a Rhino four cells away hits it. Before, FireAt
/// launched every `ROT=0` shell at `Speed=`, and `[Cannon]`'s 40 has no
/// ballistic solution past about one cell at `Gravity=6`: the Grizzly played
/// its report and reloaded, but no shell ever left the barrel.
#[test]
fn a_grizzly_hits_a_rhino_four_cells_away() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    // Facing each other (east is 64 of 256), in the arena's middle: its
    // playfield leaves the rim cells off the map, where a shell is removed.
    let grizzly = duel.spawn("MTNK", "Americans", 16, 16, 64);
    let rhino = duel.spawn("HTNK", "Russians", 20, 16, 192);
    let full = duel.health(rhino);
    duel.order(
        "Americans",
        Command::Attack {
            attacker_id: grizzly,
            target_id: rhino,
        },
    );
    let mut shells = 0;
    for _ in 0..200 {
        duel.tick();
        shells += usize::from(duel.launched_by(grizzly).is_some());
        if shells >= 2 && duel.health(rhino) < full {
            break;
        }
    }
    assert!(shells >= 1, "the Grizzly launched no shell");
    assert!(
        duel.health(rhino) < full,
        "{shells} shells launched, the Rhino is untouched"
    );
}

/// A Grizzly's `Arcing=` shell leaves its barrel (`[MTNK] PrimaryFireFLH`),
/// where its report and muzzle flash are placed too (`[ESP+0x44]`); only a
/// `Dropping=` projectile would start at the hull centre. Its launch speed is
/// GetSpeed at the 2-D distance from that barrel to the Rhino.
#[test]
fn a_grizzly_shell_leaves_its_barrel_at_getspeed() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    let grizzly = duel.spawn("MTNK", "Americans", 16, 16, 64);
    let rhino = duel.spawn("HTNK", "Russians", 20, 16, 192);
    duel.order(
        "Americans",
        Command::Attack {
            attacker_id: grizzly,
            target_id: rhino,
        },
    );
    for _ in 0..200 {
        duel.tick();
        let Some(shell) = duel.launched_by(grizzly) else {
            continue;
        };
        assert_ne!(
            shell.launch_origin,
            duel.location(grizzly),
            "the shell starts at the barrel, not the hull centre"
        );
        let event = duel
            .sim
            .fire_events
            .iter()
            .find(|event| event.attacker_id == grizzly)
            .expect("the shot's fire event");
        assert_eq!(event.fire_coord, shell.launch_origin);
        // ftol(Sqrt_Approx(d * 6 * 1.2)); four cells out, far below the
        // half-distance clamp.
        let speed = crate::sim::projectile::launch::weapon_launch_speed(
            40,
            Some(crate::sim::projectile::launch::LaunchSpeedProjectile {
                rot: 0,
                floater: false,
            }),
            6,
            fireat_launch_distance(shell.launch_origin, duel.location(rhino)),
        );
        assert!(speed > 40, "the derived speed ({speed}) beats Speed=40");
        assert_eq!(i32::from(shell.speed_leptons_per_frame), speed);
        return;
    }
    panic!("the Grizzly never launched a shell");
}

/// A Rhino driving south past the Grizzly is led: the shell is launched at
/// where it will be, south of where it stands at the shot (`0x0070BCB0`'s lead
/// along its facing). Movement runs before combat in a frame, so the Rhino's
/// position after the frame is its position at the shot.
#[test]
fn a_moving_rhino_is_led() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    let grizzly = duel.spawn("MTNK", "Americans", 16, 16, 64);
    let rhino = duel.spawn("HTNK", "Russians", 20, 10, 128);
    duel.order(
        "Russians",
        Command::Move {
            entity_id: rhino,
            target_rx: 20,
            target_ry: 28,
            queue: false,
        },
    );
    duel.order(
        "Americans",
        Command::Attack {
            attacker_id: grizzly,
            target_id: rhino,
        },
    );
    let mut moving_frames = 0;
    for _ in 0..240 {
        let moving = duel
            .sim
            .substrate
            .entities
            .get(rhino)
            .is_some_and(|entity| {
                crate::sim::movement::motion_query::is_moving(entity) == Some(true)
            });
        moving_frames += u32::from(moving);
        duel.tick();
        let Some(shell) = duel.launched_by(grizzly) else {
            continue;
        };
        if !moving {
            continue;
        }
        let target = duel.location(rhino);
        let [vx, vy, _] = shell
            .velocity
            .native()
            .map(|bits| f64::from_bits(bits.bits()));
        // Where the launch heading crosses the Rhino's column, relative to
        // the Rhino: the lead, `ftol(d / (GetSpeed * 0.9) * Rhino speed)`.
        let crossing = shell.launch_origin.y as f64
            + vy / vx * (target.x - shell.launch_origin.x) as f64
            - target.y as f64;
        // About 230 here; the unled heading crosses within ~15 of the Rhino.
        assert!(
            crossing > 100.0,
            "the shell aims {crossing:.1} leptons south of the Rhino"
        );
        return;
    }
    panic!(
        "no shell was launched at the moving Rhino ({moving_frames} moving frames); {}; {}",
        duel.actor_state(grizzly),
        duel.actor_state(rhino),
    );
}

/// A homing missile at a moving Rhino is led too, but its proximity fuse keeps
/// the Rhino's own coordinate: `ProximityDetector::Setup` (`0x004E1130`, from
/// `BulletClass::Fire` at `0x00468A93`) copies the target's unled vt+0x58
/// (`0x00468700..0x00468724`), not the led aim.
#[test]
fn a_homing_missile_fuses_on_the_unled_target() {
    let Some(mut duel) = Duel::new() else {
        return;
    };
    let ifv = duel.spawn("FV", "Americans", 16, 16, 64);
    let rhino = duel.spawn("HTNK", "Russians", 20, 10, 128);
    duel.order(
        "Russians",
        Command::Move {
            entity_id: rhino,
            target_rx: 20,
            target_ry: 28,
            queue: false,
        },
    );
    duel.order(
        "Americans",
        Command::Attack {
            attacker_id: ifv,
            target_id: rhino,
        },
    );
    let mut moving_frames = 0;
    for _ in 0..240 {
        let moving = duel
            .sim
            .substrate
            .entities
            .get(rhino)
            .is_some_and(|entity| {
                crate::sim::movement::motion_query::is_moving(entity) == Some(true)
            });
        moving_frames += u32::from(moving);
        duel.tick();
        let Some(missile) = duel.launched_by(ifv) else {
            continue;
        };
        if !moving {
            continue;
        }
        let guidance = missile.guidance.expect("HoverMissile homes (ROT=60)");
        assert_eq!(guidance.fuse_reference, missile.launch_target);
        return;
    }
    panic!(
        "no missile was launched at the moving Rhino ({moving_frames} moving frames); {}; {}",
        duel.actor_state(ifv),
        duel.actor_state(rhino),
    );
}
