# Final ordinary MTNK native evidence — HOLD

2026-10-04. Native/tool lane completed; `/root` owns final Rust/retail/Python/release/runtime/review/publication. Every repository source/corpus/meta/archive/README writer is HOLD, and all native VMs are TERMINAL. No further native execution is required for this declared chain. Worktree `/Users/halvor/Documents/vera20k-worktrees/vera20k-height`; Root safely integrated main at b5f89878fb110a33d85d24a9cb499559d5806ce7 before g4/g5.

Authoritative handoff: `final-native37-handoff.json` (all11 source/data pins,16 Unit raw receipts, final checks, binary/text identity, coverage limits and historical seals). Existing Walk corpus contains unchanged GI21 plus all15 planned Unit controls and the actual allocated-cell playfield contrast. Old7 setter/3 head and29 admission native payloads remain exact. Existing GIMoveHistory/live_cell_input/project_gi_reissue/startup owners were extended in place; no second runner/parser/normalizer/initializer or copied native body.

Original source MTNK is constructed/Unlimbo in its supplied4096 arena. Selected original Drive14 runs before its constructor; inherited prior Drive and whole process startup are explicitly excluded. Actual ordinary/Shift input→Foot resolver→literal111-byte local Move→Unit741970 reaches true743170 or guarded743184 C20800/SP+12. Dirty EAX/ClickAL are not acceptance. Literal Shift10 replaces the goal without a NavQueue append; no PlanningMode or classflag1 queue meaning is inferred.

Paid head from actual ninth UnitAI/frame531 is[3200,2688,0]. B retains it; real StopEvent6 clears Nav/destination and reduces Drive target fraction to0.30000001192092896 while retaining the paid track; repeatA guards at743184 with the complete class input state unchanged. Next actual AI continues the same head. Only prior AI1/frame523 draws two Scenario(0,2) requests/three raw advances; input/Event/class/Stop/reissue boundaries draw zero. Full Main/Scenario/Mapgen buffers, all timer3words, vector backing, raw112 Drive and ordered callbacks/writes remain retained. RawTechno2B0 is0 in the Unit scope; no unproven producer or simulation field was added.

Mode5/currentHouseNULL and Berserk298=1, separate6E0/6E1/6E2 priors all yield query0/no Move/resolver/class and exact retained target/mission/nav/Drive/timers/RNG. AL1 for House/deployment and AL0 for Berserk are incidental no-order returns. Delayed6E0 after actual Move construction allows the Event prefix then a guarded class no-op. These are component priors on stockMTNK, with no deployment cycle/incidence claim.

Actual Shift request4,20/action2 resolves through original4DE1D0/FNPC to4,19. MapSize[16,16], LocalSize[0,0,32,32], full header/land/navigation and requested/actor/A/resolved Cell inputs are retained. Every r7 selected field equals r8 before additive observation exports. Failed40,20 fixture-prerequisite and31,20 non-distinguishing attempts remain immutable failed receipts. No arbitrary terrain/shroud/zone/Dummy coverage claim.

The59-provider map is unchanged from actual complete default no_rally/rally and both publication comparisons. Both full PUBLIC before_strip(r5)/after_strip(r6) wrappers PASS and remain active, with all old source/data/digests/rejections/protected maps preserved. Final fresh Walk legacy/source/saved37 check, admission29 check, full factory saved/public-source check and15 publication rejection controls PASS. Root g5 PASS63/0/0; Root final full checks have not yet been run by this lane.

Historical GI validation remains untouched. Its native manifest identity b90c182f52a7504741de7f0a9bf65570ed1999e42da10adbd7c46e778494a151 resolves specifically to decompressed `compatibility/sealed-gi21-pre-unit-manifest.json.gz`, not active37 or the separate earlier as-run-g16 source roster. Root owns a distinct Unit validation archive and measured/runtime proof.

No whole-world, bootstrap, Rust whole-AI/scheduler, display-input, arbitrary-map-loader, factory-contact, network or save-load parity claim. Continue HOLD through Root validation/publication unless Root explicitly releases a required native/tool fix.

Final active pins:

- tools/spatial_oracle/walk_first_path.py: 74988ef139174e6e153623607d1906b5651afe870d246e32d91c630961012096
- tools/spatial_oracle/walk_first_path.json: 80f8d7c9355c960b1756033b77dd1ba6362b3314c9e61cf38d5a7c82a8f62525
- tools/spatial_oracle/walk_first_path.meta.json: b694e791afaa39d90b41599530b494a15d532d4a60f710f84f8209d4f5ff5b33
- tools/spatial_oracle/_walk_first_path/manifest.json: eb53699b9766cc3958a132e1f51c1fe5ec442cefaa057afeb4803640544ebd58
- tools/spatial_oracle/_walk_first_path/README.md: 1ab66edb64451d222ef817b1669808d3400594835b3ddf894a07aa2d90ea2d15
- tools/spatial_oracle/_factory_infantry_output/meta.json: 1dd0e15d4fb48da534b74e54cb92eaaa9e63d5abae397c6bd9994befbedc9aac
- tools/spatial_oracle/building_death_anims.py: ef064ae5e38e5f912c6c61796588786bd787df239099721622a70b7f77aa726e
- tools/spatial_oracle/_factory_infantry_output/initialized.py: 77c0d85bebf497122f63345626e3f5d5fa19891e2117a9986f5fc9245b4d7c6a
- tools/spatial_oracle/_factory_infantry_output/runtime.py: 351141aa2f19e79e23752cc0d38f3eabd216663dbcde3d5c9e782e092b75fae6
- tools/spatial_oracle/walk_move_admission.py: 4bcc4da01463be56ce088d0356e44ab23f2ea637a68ff8a5ce26b86d0b7f1f89
- tools/tests/test_factory_infantry_output.py: a4137b0031a101f9196e40775718aa9a6874bad44875ab3001be9ee503477016

Handoff SHA256: 19d7191434cf1124ddf197f898be35e61a3dcf90e004d1d388396b1bb4743783
