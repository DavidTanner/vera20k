# Source MTNK sight bootstrap and current Unit37 bounds

Read-only report, 2026-10-04. Context: merged-main `a8b4303a637958cb22125cbee14fc97e23ffce2f` plus Root-owned Unit WIP. No native execution, repository/profile/corpus/archive edits, Cargo, app or Git/Ghidra mutation. All native writers remain **HOLD**. This is prerequisite research, not a critic or #692 implementation.

The source MTNK already has native sight admission when `initialized.generate` invokes its live continuation. The footprint geometry is outside the Native37 claim: its underlying world omits two original spread CRT producers and starts Cells from supplied mapped bytes. Current Unit movement comparisons explicitly depend on the supplied revealed client view; this report does not assert global table independence.

## Established inputs and bootstrap ownership

The [retained accepted receipts](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/_walk_first_path/accepted) and [final handoff](/Users/halvor/Documents/vera20k-dev/refactor-goal/movement-unit-native-v1-20261004/final-native37-handoff.json) (SHA `19d7191434cf1124ddf197f898be35e61a3dcf90e004d1d388396b1bb4743783`) were decoded, compressed/uncompressed hashes checked for all16 Unit controls, and current59 imported helper hashes read back exact. Profile remains `e9e2f722257df6b510d2f17d95e5f866cef0a4217660833cef6ff645191b8e09`. The [guiding packet](/Users/halvor/Documents/vera20k-dev/refactor-goal/movement-height-sight-joined-observer-b0b6dafc-20261004.md) has SHA `6048ab6a945a128f46ae430708bf96917933ca11022bf9c94d4b331b18f0bca5`. Native executable SHA `1cdd1180e49024fbda8ad568caac2e86e856063ff67ab38f62b7d2c7bb84298c`; text identity remains `4cd5557a7490debc493ff965afc4483d8d2f1065f434f6b665cbb8fc4835b0cc`.

`building_death_anims.joined_fixture` (627) creates the reused Engineer/JoinedFixture VM. Selected original Infantry/Object/Drive CRT startup precedes source MTNK construction; `f.source=f.allocate(0x1000)` is supplied arena storage. Original Unit7353C0 (894) constructs it; original737BA0 (909) Unlimbos it at authored `[2944,2176,0]`, facing128. Foot4D7170 calls Techno6F6CA0; Techno6F6D27 invokes class+488, which original UnitVT7F5C70 resolves to See70AF50 (+48C is Lose70B1D0). Native Type/House/Map gate3D5 and sight admission execute inside that corridor. No See result is supplied.

Techno constructor6F2D68/96/9C initializes250/260/264 tozero and initializes254 XYZ. See's admitted first-source arm70B0CB..E3 sets250=1, saves current XYZ254 and radius260. It does **not** write264. All16 retained initial actor raw bytes independently contain250=1,254=`[2944,2176,0]`,260=8,264=0. The retained264=0 is constructor state; Foot's later high-flight refresh4DA78E is its observed instruction-level writer, not an ordinary See write.

`initialized.fixture_boundary` (64–70) receives `f` only after source constructor/Unlimbo. It starts selected Walk/Foot CRT for later GAPILE/E1, and is too late to observe source's first See. `factory.generate` (177) clears inherited executed/trace/event/RNG-call lists after setup. Consequently the saved live history does not retain a complete first-source sight callback trace; caller/body evidence explains the retained state without inventing new execution observations.

## Cell priors and the missing geometric prerequisite

`unit_source_scatter.make_source_fixture` (25–39) freshly maps1024 Cells and supplies VT/XY/level/flags/overlay fields; it does not execute Cell47BBF0. Thus130/134 and120/121 initially remain mappedzero. Native47BBF0 actually sets130=1,134=0,120/121=−2 and clears12C lowbits; [shroud_current_sight](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/shroud_current_sight.py):23–35 supplies those constructor-derived leaf priors separately. Its leaf current-sight controls are not the joined bootstrap.

`EngineerJoinedFixture.repair_target_prior` (922–927) supplies12C=0x18 across all1024 Cells. Later original CLEAR01 Recalc47D2B0 derives terrain, and original source/GAPILE/E1 admission/cache callbacks run on those supplied Cells. The complete retained baseline contains only four nonzero130 centers:11,8=−205;14,14=−89;14,16=−89;16,16=−89. The source center caches are[-1,−2],134=0,12C=0x18,140=2. Radius count table7ED3D0 contains `[1,9,21,37,61,89,121,161,205,253,309,369]`.

Original process slots813AA4/813AA8 contain561900/5638C0, jump thunks to561910/5638D0. They build respective packed-offset tablesABD490/ABCF60. Both tables are BSS; `native_oracle.load_image` (290–303) zero-fills BSS and performs no OS initialization. The joined startup caller lists exclude these two entries and do not copy those globals from the reader VM. Existing `anytown_damage.mtnk_attack.attach_world`:124 executes561910 in its own world composition; that call is not reached by the current joined world setup. Neither it nor the IFV initializer is an alternate owner to copy here.

See traversal567A63..567B46 takes the count from7ED3D0 and successive offsets from both tables; Map567DA0 cache traversal also readsABD490. The concentrated −205/−89 center counters are consistent with these cold offsets. **The old receipts do not export actual offset-table bytes or a first-See ordered trace**, so this remains source/body-founded causality, not a newly executed table-state measurement or a physical sight-footprint claim. Do not reset counters or clear250 to repair it after bootstrap.

## Callbacks and current Unit37 causal bound

No inspected inherited hook supplies See70AF50, Lose70B1D0, Map5678E0/567DA0,653830,Display4A9CA0,Tactical6D8700/6DA7D0 or Cell487630/487690. Their admitted original paths reach the counter/cache/dirty-notification bodies. `JOINED_TRANSPORT` supplies GUID/COM/import transport, radar655560/655740 and VXL setup returns; `building_construction.PRESENTATION` supplies451F60/452170/456FB0/705D70. Those presentation/import boundaries and lexical INI/asset/allocator inputs remain explicit seams, not sight-answer stubs. Radar/device output and renderer pixels are excluded.

Original query7404B0→4DDDE0 uses586360 at4DDE6E and7405DB. On these flatZ0 inputs,58647A tests **Cell12C bit8**, returning AL0 when set; it does not read130/134,120/121 or the spread tables. 5656D0 likewise reads12C bit8. Every accepted Unit initial type hasMoveToShroud=1; resolver4DE26B skips its early shroud rejection, but **still executes586360 at4DE3B5**, then combines shrouded/playfield/high-flight and zone checks at4DE455..4DE4BB or FNPC4DE528. The outside-playfield control therefore remains meaningful but uses an explicitly revealed view, including queried4,20 and chosen4,19. The query is not independent of visibility.

Original Move Event4C7353..4C747C has no direct sight-counter/table read: it performs mission/target/history/archive prefix, then class destination741970. Unit destination and UnitCanEnter73F0A0 contain no direct130/134/cache/table read; their shared Foot bridge entry4D9C60 uses140's bridge masks100/200, rather than the reveal bit2. This is body-level scope, not an exhaustive whole-game virtual-call graph proof.

All16 complete recorded continuations have **zero Cell130/134 writes, zero120/121 writes and zeroactor250..267 writes**, as mechanically counted below. The three paid controls have9 original UnitAI visits before reissue and oneafter. Visits1..8 retain2944,2176;visit9 reaches2955,2187 (still Cell11,8);nextAI reaches2974,2206, or2961,2193 afterStop. Paid head remains3200,2688. Thus no complete native head arrival or source-footprint release/readmit was demonstrated. The normal high-flight sight refresh is guarded by4DA6A4→Foot4DE620→5F6B90: marked height must be at least2*AC13C8; retained groundZ0/OnBridge0 does not meet that gate. Normal Unit arrival suffix73AC52 does Lose→See→Map cache before Ready/Commence, but is beyond the retained paid prefix. Foot's nonhuman83 shroud cleanup4D8DA7 is additionally gated by House50B6F0; these controls have the matching human current owner.

The collector records ordered writes/calls, **not all memory reads**. Unobserved presentation/cache or other nested AI readers are therefore a named uncertainty; no claim is made that every one of the9 wholeAI visits reads no affected sight state. Current command/paid-state goldens are bounded by the exact supplied revealed-view/bootstrap priors and the native fields/RNG actually compared. They do not certify sight, rendering, full arrival or whole-map parity. Old Native37 data/profiles remain immutable.

| Accepted control | Whole UnitAI visits | Writes130/134 /120/121 /250..267 |
|---|---:|---:|
| unit_plain_A_B | 0 | 0/0/0 |
| unit_shift_A_B | 0 | 0/0/0 |
| unit_deployed_delayed_A | 0 | 0/0/0 |
| unit_paid_head_B | 10 | 0/0/0 |
| unit_paid_head_Stop_B | 10 | 0/0/0 |
| unit_deployed_B | 0 | 0/0/0 |
| unit_shift_outside_playfield_B | 0 | 0/0/0 |
| unit_paid_head_same_A | 10 | 0/0/0 |
| unit_plain_A_A | 0 | 0/0/0 |
| unit_shift_A_A | 0 | 0/0/0 |
| unit_plain_A_later_B | 0 | 0/0/0 |
| unit_shift_A_later_B | 0 | 0/0/0 |
| unit_owner_mismatch_B | 0 | 0/0/0 |
| unit_berserk_B | 0 | 0/0/0 |
| unit_deploying_B | 0 | 0/0/0 |
| unit_undeploying_B | 0 | 0/0/0 |

## Smallest authorized future extension after Unit merge

Extend the existing `joined_fixture` selected startup/caller owner with an optional observation selection installed **before source7353C0/737BA0**, retaining it across GAPILE/E1 setup. Observe current counters/tables before firstSee, constructor/Unlimbo admission, See/Lose/Map/Cell/cache entries and trueRET cleanup: SeeRET20, LoseRET16, Map5678E0RET32, Map567DA0RET16 and Cell-map4A9CA0RET12. Retain both call-entry and return SP; do not use dirty void EAX as admission. Extend the same GIMoveHistory snapshot/projector with sight250/254/260/264/3D5/420,65C timer, original typeSight5E8/veterancy and already-read Rules17EE/680/16BC, actual House/passivity/alliance/current-viewer priors, rawCells and current shroud AL through the existing leaf reader. Do not synthesize an initialSee, release/reason2 callback, path or query answer.

Before declaring a physical footprint, execute the registered two-entry spread startup in that existing VM before the first sourceSee, and establish constructor-derived Cell priors in the existing map initialization owner before any admissions; preserve the default old control selection. Then run actual Move/Event/UnitAI/DriveProcess until the real739EC0 reason2 caller reaches73AC52, retaining old/new footprint cells, counter/cache/flag writes, exact global/height inputs, all3 RNG streams/order, timers/FPCW and trueRET boundaries. Flat height0 is the first joined control; ramp/TMP/bridge/height sight consequences require separately observed applicable priors. WholeGeneral66D530 already runs each physical layer; export its values rather than repeat or invent a reader.

Execution questions left open: exact cold/new table bytes and actual startup ordering; per-source firstSee call counts across source/GAPILE/E1; Cell constructor/default-visible-view composition beforefirstadmission; corrected geometry's possible effects on nested AI/presentation; actual paidarrival release/readmit and height-dependent radius/rounding. Any future changed-provider admission requires existing complete no_rally/rally/public comparison gates and preservation of old7+3/admission29/GI21/Unit16. No such implementation or replay was performed here.

## Read-back source identities

| Owner | SHA256 |
|---|---|
| [tools/native_oracle.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/native_oracle.py) | `141fc5f3981b40d41869643c0350e3988e40be2e470cba8a0b4a77bb7df39b27` |
| [tools/spatial_oracle/unit_source_scatter.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/unit_source_scatter.py) | `3384579566b40ebcc9d8d56d53a0736655eb3a15a6bf7f08730611b15852a009` |
| [tools/spatial_oracle/building_construction.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/building_construction.py) | `65ddb0c37fc111758368780881ecbdca828c0153e9eb945f4e1ea72a20b9a438` |
| [tools/spatial_oracle/engineer_repair_admission.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/engineer_repair_admission.py) | `626e404d7ae92ed14520c87cef9b0157838120aff109ada925e5acc9e7f49777` |
| [tools/spatial_oracle/building_death_anims.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/building_death_anims.py) | `ef064ae5e38e5f912c6c61796588786bd787df239099721622a70b7f77aa726e` |
| [tools/spatial_oracle/_factory_infantry_output/initialized.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/_factory_infantry_output/initialized.py) | `77c0d85bebf497122f63345626e3f5d5fa19891e2117a9986f5fc9245b4d7c6a` |
| [tools/spatial_oracle/_factory_infantry_output/factory.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/_factory_infantry_output/factory.py) | `001bc9ded95c782f6391558d19a40ec629e7c14b2ee696c0f1b29c5dd4b82537` |
| [tools/spatial_oracle/_factory_infantry_output/admitted.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/_factory_infantry_output/admitted.py) | `0cafa086f26836a8a2caa8ae6287f8d705e4bd38095faa454b8d298888f6d81f` |
| [tools/spatial_oracle/_factory_infantry_output/construction.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/_factory_infantry_output/construction.py) | `1dbee3bdd54832e8a32d2cdb8845da62607b0f79f8f6c469e1d6f6f5f2b3424b` |
| [tools/spatial_oracle/walk_first_path.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/walk_first_path.py) | `74988ef139174e6e153623607d1906b5651afe870d246e32d91c630961012096` |
| [tools/spatial_oracle/shroud_current_sight.py](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/tools/spatial_oracle/shroud_current_sight.py) | `661a4b569464cdeae75a9839916c24159177d0731b7d674f0c9859897df6f173` |

## Original instruction/data pins

Spans below are original PE bytes obtained with the existing identity-checked `image_bytes`/`file_span` owner and Capstone inspection; end addresses are exclusive. This is static inspection, not emulation. Reproduce disassembly with the existing `tools.native_inspect` `disasm <start> --bytes <length>` command; the CRT and count rows are data, not instruction starts. Full function/fragment lengths are explicit; no Ghidra annotation supplies a result.

| Original body/data | Span | SHA256 |
|---|---|---|
| Techno ctor | `006F2B40..006F3267` | `d3dc290876aa8f313ea2d9c4dbf19ba782288133052f7b5c573d23338e13af3c` |
| Unit Unlimbo | `00737BA0..00737C88` | `a343859b64ceec78786d136142143896b45126d1e944b21a588fd8afe686994c` |
| Foot Unlimbo | `004D7170..004D732A` | `3839541838d123e8eeaaaefeb5b0a778f38015d7f71627a386a8271cd5849272` |
| Techno Unlimbo | `006F6CA0..006F6F33` | `23375296f960ad0063a0ff3b316069d6de194effcb6a1581fb990a66e0171249` |
| See | `0070AF50..0070B1D0` | `ac5952fa83990a144af3d7b46f62cfa359f16a90eadd60ccbfaba84a9d4f91b4` |
| Lose | `0070B1D0..0070B275` | `c4164cbda6a8ce2aafae85d7118c2aa11cef611c293b7b890084be56f71707b2` |
| Cell constructor | `0047BBF0..0047BDA8` | `abc5f47c9d770dd4341ba5167e5841f4c347d59a13d9b810edfd696506553c99` |
| spread CRT slots | `00813AA4..00813AAC` | `43896e45b01083f581ecbb1054cf3953e5f09276196053a474af6248cc65c148` |
| spread ordinary producer | `00561910..005638B6` | `75b80a3d51723b2a9ed1c4477cb6d574426254cf9eeb2fb4821ecd8546f463ca` |
| spread second producer | `005638D0..0056505C` | `4df151141a6a8ef1ab629c8db1b36aa48410f3a101e38ea5a607411a15fb8f7e` |
| radius counts | `007ED3D0..007ED400` | `ad889698c5928fd25ea17d217321b2ff9918a1cc1be1b783e4bb9aecba8d17bc` |
| See Map traversal | `005678E0..00567D92` | `6a9d6c03b9812f8a15f1eb3e0d3e1792d3bc853a876c4d046233831ce2f5ebc2` |
| Display Cell admit/release | `004A9CA0..004A9DC9` | `1e24d8a11c2b2e891c6ed17780e439c00399fb7c9ba60c86436dbf5cce10193a` |
| Cell counter leaves | `00487630..004876F0` | `58fa214624acf665cb5daa0be97b3b36d92793f91400c6fa12b0a740746e5bb2` |
| IsShrouded | `00586360..00586495` | `d63093174075999e4457c40fe5c28121d3a33666a7edee5e0a42ad4e6f892001` |
| Cell visible | `005656D0..00565728` | `adb84a09647c40c4ade29258f947d25dba70efab32ab82c1c3b1f603ecac37ee` |
| Unit WhatAction | `007404B0..0074080F` | `67b10efb5b750fd663e9c38482538c0589820400d51a1a886f589ba6a89fb490` |
| Foot WhatAction | `004DDDE0..004DDECC` | `f08085bf9edbefe20f3a286c533ec4c622260762d20fb7fc3e809b3f6d243058` |
| Foot Cell resolver | `004DE1D0..004DE577` | `5f8c8266b8e91cd3264881597ff4355c7df619c8c283ef1d132f302e0099ff96` |
| Unit CanEnter | `0073F0A0..0073FD46` | `78e23eb52df57362a626578bc6ca9c13a130351171011a9d73e8de4644747af2` |
| Foot bridge admission | `004D9C60..004D9E67` | `7069725e7872089cc82d2cc5ade2c904f643198c33ebab1651e250c50fa4384b` |
| Unit destination | `00741970..00743187` | `874f5dbdda5ac47b6b6ba12a6a18ba36f998bb9a56c0c41e4acf1b3ff2d9a9ce` |
| Move Event arm | `004C7353..004C74B2` | `3d526bff8852ce33838ae6071a9d65f7067310ef749936f107bcd3c6267b6ebb` |
| Unit arrival sight/promote suffix | `0073AC52..0073ACD7` | `32c068914ff9414ce43c08caf6d89d1aa0adf5eff0415057a712ed0c95500ab9` |
| Foot high-flight refresh fragment | `004DA690..004DA7B0` | `60d09be356da01cd91e5439976781c48f4c8298baeaf407f73d5b94b21d9a3af` |
| Marked high-flight predicate | `005F6B90..005F6BB2` | `3bc7c6a09d2a1267724e5794089f37ac3b3400e2338e0e99c525978068951f2e` |
