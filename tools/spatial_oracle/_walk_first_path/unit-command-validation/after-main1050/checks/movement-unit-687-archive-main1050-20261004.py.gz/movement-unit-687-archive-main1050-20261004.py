"""One-off final integrated validation supplement; preserve earlier as-run bytes."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
NATIVE = BASE / 'movement-unit-native-v1-20261004'
OLD = ROOT / 'tools/spatial_oracle/_walk_first_path/unit-command-validation'
DEST = OLD / 'after-main1050'
HEAD = 'a8b4303a637958cb22125cbee14fc97e23ffce2f'
PLAN = BASE / 'movement-unit-687-post-main1050-validation-invocation-plan-20261004.json'
PROOF = BASE / 'movement-unit-687-runtime-proof-main1050-20261004.json'
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
assert not DEST.exists(), 'Preserve an existing supplement; never overwrite'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
old_manifest_bytes = (OLD / 'manifest.json').read_bytes()
assert sha(old_manifest_bytes) == '1448784d364c84d1012ff165cb0d8b7f81746f5a8645598f855c9781aba98f65'
old_manifest = json.loads(old_manifest_bytes)
assert old_manifest['base'] == '24330e019e3875d001fcd16c1141355f8648c3a1'
assert len(old_manifest['files']) == 114
for relative, pin in old_manifest['files'].items():
    stored = (OLD / relative).read_bytes()
    assert len(stored) == pin['bytes'] and sha(stored) == pin['sha256'], relative
    data = gzip.decompress(stored) if pin['gzip'] else stored
    assert len(data) == pin['uncompressed_bytes'] and sha(data) == pin['uncompressed_sha256'], relative
old_readme = (OLD / 'README.md').read_bytes()
assert sha(old_readme) == 'ec824cf8471d1232e5ba17205a6ebd047a8debd9da6cd2c1619ceeedc9b77e73'
runs = [
    ('full', 'movement-unit-687-final-full_lib-f4-20261003'),
    ('clippy', 'movement-unit-687-final-clippy_lib-f4-20261003'),
    ('primary63', 'movement-unit-687-final-primary63-f4-20261003'),
    ('python', 'movement-unit-687-final-python_suite-p2-20261003'),
    ('release', 'movement-unit-687-final-release_game-f4-20261003'),
]
receipts = {label: load(BASE / (stem + '.json')) for label, stem in runs}
sources = receipts['full']['source_files']
assert len(sources) == 1982
for label, stem in runs:
    receipt = receipts[label]
    assert receipt['cargo_run_exit'] == 0 and receipt['source_unchanged'], label
    assert not receipt['compile_error'] and not receipt['observed_test_failure'], label
    assert receipt['source_identity']['head'] == HEAD, label
    assert receipt['source_files'] == sources, label
    assert receipt['invocation_plan_sha256'] == sha(PLAN.read_bytes()), label
    assert sha((BASE / (stem + '.log')).read_bytes()) == receipt['log_sha256'], label
assert receipts['primary63']['test_summaries'][0][:4] == ['63', '0', '0', '0']
assert not receipts['primary63']['fixture_skip_marker']
for relative, digest in sources.items():
    assert sha((ROOT / relative).read_bytes()) == digest, relative
native = load(NATIVE / 'final-native37-handoff.json')
for relative, pin in native['source_pins'].items():
    data = (ROOT / relative).read_bytes()
    assert len(data) == pin['bytes'] and sha(data) == pin['sha256'], relative
audit = load(NATIVE / 'main1050-native-closure-readonly-audit.json')
assert audit['status'] == 'PASS' and audit['integrated_head'] == HEAD
assert all(not entry['changed_paths'] for entry in audit['protected_map_intersections'].values())
assert audit['saved_public_check']['terminal_exit_code'] == 0
assert audit['saved_public_check']['identical_to_final_native37_saved_check_log']
proof = load(PROOF)
assert proof['status'] == 'PASS'
assert proof['classification'] == 'Rust production observation; no native comparison'
assert proof['paid_head_before_reissue'] and proof['paid_head_before_stop']
assert proof['paid_head_retained_after_reissue'] and proof['paid_head_retained_after_stop']
assert proof['final_arrival']
DEST.mkdir()
files = {}


def preserve_bytes(data, relative, origin):
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', compresslevel=9, mtime=0) as archive:
            archive.write(data)
    stored = target.read_bytes()
    assert gzip.decompress(stored) == data
    files[relative] = dict(bytes=len(stored), sha256=sha(stored), gzip=True,
                           source=origin, uncompressed_bytes=len(data), uncompressed_sha256=sha(data))


def preserve(source, relative):
    data = source.read_bytes()
    preserve_bytes(data, relative, str(source))
    assert source.read_bytes() == data, source


for label, stem in runs:
    for extension in ('json', 'log'):
        preserve(BASE / (stem + '.' + extension), 'checks/' + label + '.' + extension + '.gz')
for source in [PLAN, BASE / 'movement-unit-687-main1050-integration-20261004.json',
               BASE / 'movement-unit-687-field-ratchet-main1050-20261004.txt',
               BASE / 'movement-target-689-measure-red-20261003.py',
               BASE / 'movement-unit-687-runtime-proof-20261004.py', Path(__file__)]:
    preserve(source, 'checks/' + source.name + '.gz')
for name in ['main1050-native-closure-readonly-audit.json',
             'main1050-readonly-factory-saved-check.log',
             'main1050-native-closure-readonly-r1-rejected.json']:
    preserve(NATIVE / name, 'native/' + name + '.gz')
preserve_bytes(old_readme, 'historical/main243-readme.md.gz', str(OLD / 'README.md'))
changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=ROOT, text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines())
for relative in sorted(changed):
    if relative.endswith(('.rs', '.py')) and (ROOT / relative).is_file():
        preserve(ROOT / relative, 'as-run/' + relative + '.gz')
preserve_bytes(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT),
               'as-run/candidate.diff.gz', 'git diff --binary HEAD at ' + HEAD)
preserve(PROOF, 'runtime/proof.json.gz')
for run in proof['runs']:
    directory, offline = Path(run['directory']), Path(run['offline_validation'])
    assert load(offline)['status'] == 'VALID'
    assert sha(offline.read_bytes()) == run['offline_validation_sha256']
    preserve(offline, 'runtime/' + directory.name + '/offline.json.gz')
    for source in sorted(directory.rglob('*')):
        if source.is_file() and source.name != 'config.toml':
            preserve(source, 'runtime/' + directory.name + '/' + source.relative_to(directory).as_posix() + '.gz')
for source in sorted((BASE / 'movement-unit-687-runtime-inputs-20261004').iterdir()):
    if source.is_file():
        preserve(source, 'runtime/inputs/' + source.name + '.gz')
manifest = dict(schema_version=1, scope='Final integrated ordinary MTNK Cell command owner chain',
                base=HEAD, integrated_pr=1050, source_files=sources,
                historical_archive=dict(base=old_manifest['base'], files=114,
                    manifest_sha256=sha(old_manifest_bytes), readme_sha256=sha(old_readme),
                    executable_sha256='b534f3cca1fceb6a5e6a27545316a5178bca700db245ac0afb5aeae00d6b1424',
                    offline_validation='VALID at original recorded time; executable path is reused by newer unlabelled build'),
                native_sha256=native['native_sha256'], native_source_pins=native['source_pins'],
                native_audit_sha256=sha((NATIVE / 'main1050-native-closure-readonly-audit.json').read_bytes()),
                runs={label: {key: receipt.get(key) for key in
                      ('argv', 'cargo_run_exit', 'wall_seconds', 'test_summaries', 'fixture_skip_marker', 'log_sha256')}
                      for label, receipt in receipts.items()}, runtime=proof, files=files,
                historical_bounds=old_manifest['bounds'],
                bounds=native['coverage_bounds'] + [
                    'Paid original AI priors are imported for Rust command comparisons; whole AI is not replayed.',
                    'Retail release observation is Rust production evidence, not native pixel/gameplay equivalence.',
                    'Decoded queue compatibility input is not a physical keyboard Shift observation.',
                    'Bunker fixture fixes movement cadence; complete Bunker owner/query/cadence remains #690.',
                    'Ship naval factory prewrite/queue migration and other adapters remain #687/#689.',
                    'Runtime machine config bytes are omitted; original identities remain in run receipts.',
                    'Historical main243 measurements are retained with their original identities; final validation is on main1050.',
                    'The historical native as-run README predates the final pinned README; the separate rejected equality assertion is a documentation diagnostic.',
                    'Incoming main1050 changes no registered native helper/profile or caller closure, so no renewed native replay/rebind was required.',
                    'Full/Clippy/primary63/Python/release final measurements all use the identical 1982-source candidate.',
                    'All16 Unit native histories use an explicitly revealed-view fixture: Cell12C=0x18 and MTNK MoveToShroud=1. They do not compare sight counters or footprint geometry.',
                    'Existing joined-fixture reveal spread tables were zero-filled; real sight-table startup and complete arrival sight cadence are prerequisites for the later #692 chain.',
                ])
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
readme = f'''# Final integrated MTNK command-owner validation

This supplement records the unchanged Unit command-owner candidate after main PR #1050, base `{HEAD}`. The incoming capture/combat code was integrated without conflicts. All five final measurements use the same 1,982 Rust/Python source identities. The [historical archive](../manifest.json) and its 114 files retain their original main243 identities; [its original README](historical/main243-readme.md.gz) is preserved verbatim.

| Check | Actual result | Retained receipt |
| --- | --- | --- |
| Retail full library f4 | {receipts['full']['test_summaries'][0][0]} passed; {receipts['full']['test_summaries'][0][2]} ignored; 0 failed | [receipt](checks/full.json.gz), [log](checks/full.log.gz) |
| Clippy f4 | exit 0; warnings present | [receipt](checks/clippy.json.gz), [log](checks/clippy.log.gz) |
| Required retail primary63 f4 | 63 passed; 0 ignored; no fixture skips | [receipt](checks/primary63.json.gz), [log](checks/primary63.log.gz) |
| Python suite p2 | 613 tests; 5 optional skips; successful | [receipt](checks/python.json.gz), [log](checks/python.log.gz) |
| Fresh release f4 | exit 0; exact final source census | [receipt](checks/release.json.gz), [log](checks/release.log.gz) |
| Production map observation r2 | 500 steps; capture/offline VALID; paid reissue, Stop and arrival observed | [proof](runtime/proof.json.gz) |

The [invocation plan](checks/movement-unit-687-post-main1050-validation-invocation-plan-20261004.json.gz) preserves exact retail selectors, required INIs/assets and map overrides. [The manifest](manifest.json) pins compressed and original bytes, all source identities, native identity and measurement results. [The integration receipt](checks/movement-unit-687-main1050-integration-20261004.json.gz) records the recoverable stash and clean overlap merges. The [field-ratchet result](checks/movement-unit-687-field-ratchet-main1050-20261004.txt.gz) remains 2,505 against 2,505.

The [read-only native closure audit](native/main1050-native-closure-readonly-audit.json.gz) found no incoming intersection with the 11 final Native37 pins, 59 registered native helpers, profiles, inspection owner, Gate18 or caller maps. All 78 as-run native code/profile entries remain exact. The [saved public check](native/main1050-readonly-factory-saved-check.log.gz) exited 0 with byte-identical output. A [retained rejected equality assertion](native/main1050-native-closure-readonly-r1-rejected.json.gz) compared a historical as-run README to later final documentation; both identities remain explicit. This was a documentation assumption failure, not a gameplay mismatch, and required no new native execution or metadata rebind. See [the original native notes](../../README.md) for executed native coverage.

The covered Unit native histories use an explicitly revealed-view fixture: all baseline Cells retain `+12C=0x18` and MTNK `MoveToShroud=1`. The original input/resolver still depends on that revealed-view answer. Existing joined-fixture reveal spread tables were zero-filled; the retained source sight counters therefore do not establish a physical footprint. All 16 accepted Unit histories, including paid priors and the next UnitAI visit, record no sight-counter/cache/admission writes and stop before full Cell arrival. These are bounded command/movement-field comparisons. Real sight-table startup, full footprint geometry and arrival sight cadence remain prerequisites for the later #692 chain.

The fresh release binary SHA256 is `{proof['executable']['sha256']}`. Actor {proof['actor_id']} visited {proof['distinct_positions']} physical positions and {proof['paid_head_frames']} paid-head frames in 501 snapshots. The existing paid head remained across destination B and Stop; the final ordinary Move arrived and retired. The unchanged profile/map and exact capture, offline validation and proof are retained. This is **Rust production observation with no native comparison**. Decoded queue=true exercises compatibility dispatch; physical Shift belongs to the separately executed input tests. The earlier release binary `b534f3cca1fceb6a5e6a27545316a5178bca700db245ac0afb5aeae00d6b1424` was VALID at its original validation time; the unlabelled executable path is now reused. No executable copies are retained.

The [parent notes](../README.md) describe the mechanism and remaining goal work. #687/#689 retain other adapters, traffic and the Ship naval-factory prewrite/queue caller; #690 retains the full Bunker arrival/query/cadence migration. Whole AI/factory/Windows delivery, Planning and AttackMove remain outside this bounded command comparison. This chain does not close the movement/height goal audit.

Reproduce with the saved invocation plan and repository-owned Cargo runner. The retained runtime profile/map can be passed to `python -m tools.map_observation --profile PROFILE --contract CONTRACT --cwd CHECKOUT --output NEW_DIR`, then `validate --run NEW_DIR --output NEW_JSON`. Preserve new outputs separately.
'''
(DEST / 'README.md').write_text(readme)
old_text = old_readme.decode()
old_text = old_text.replace('# Ordinary MTNK command-owner validation', '# Ordinary MTNK command-owner validation — historical main243', 1)
notice = '\nThis page records the historical candidate on main243. The final integrated main1050 candidate and repeated final checks are recorded in the [after-main1050 supplement](after-main1050/README.md). The historical manifest and all 114 archived files remain byte-exact; its original README is preserved in that supplement.\n'
first, remainder = old_text.split('\n', 1)
(OLD / 'README.md').write_text(first + '\n' + notice + remainder)
assert (OLD / 'manifest.json').read_bytes() == old_manifest_bytes
print(json.dumps(dict(archive=str(DEST), files=len(files), manifest_sha256=sha((DEST / 'manifest.json').read_bytes()))))
