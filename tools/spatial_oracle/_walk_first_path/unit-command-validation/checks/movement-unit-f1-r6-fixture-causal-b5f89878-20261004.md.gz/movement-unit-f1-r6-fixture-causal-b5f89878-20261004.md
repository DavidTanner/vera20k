# Unit f1/r6 fixture causal evidence — b5f89878 / 2026-10-04

Read-only debugging assistance, not the Unit critic. Scope is the two moving-Rhino projectile regressions and the Bunker component-fixture stall. This note writes no repository source, native provider, metadata, corpus or archive and performs no Cargo/game/native-VM execution. Original file-backed instructions were inspected through existing `tools.native_oracle`/`tools.native_inspect`; previously executed controls are distinguished below.

Checkout: `/Users/halvor/Documents/vera20k-worktrees/vera20k-height`, task-owned `feature/unit-move-command-owner`. Both f1/r6 ran at HEAD `b5f89878fb110a33d85d24a9cb499559d5806ce7` with owned dirty Unit changes. At final note readback Root had fast-forwarded the docs-only #1049 to HEAD `24330e019e3875d001fcd16c1141355f8648c3a1`; no incoming Rust/native code overlap was reported. The current source column below binds the post-g6 one-Process Bunker simplification, not f1/r6's old fixture.

## Actual saved validation boundaries

All artifacts below are in `/Users/halvor/Documents/vera20k-dev/refactor-goal/`. Their receipts contain exact argv, source_files and source_identity; the table pins the complete receipts/logs rather than reconstructing them.

| Run | Receipt SHA256 | Log SHA256 | Recorded aggregate source SHA256 | Sources unchanged / Cargo exit |
|---|---|---|---|---|
| f1 | `ca9428af73bdbc9d266be86f6ad9dae1e4d20cd7800c3fcd836c8efe9a5cf8f8` | `9567846108a636adec65a8019792d920fc73e50396fcf5c08aca64934ff6989a` | `db6a1ee8a61aab9fe1dacd54f935604d4fcfee2afe47156ca1e8413d2841e2ce` | True / 101 |
| r6 | `9cfa4827ee7059ad4e27069b7e4662feac1f40f6906bc01e7e61fb0837335c18` | `270862489c39602d7f2eac979ae3c91be1c3798e25ff97da99bba87554932b86` | `2453be8a9f2596067c2271efd51271fed6471986fb76bcc9a6e596021348d2fc` | True / 101 |
| g6 | `bdd3768a4ac4fe215f093212d1ec51b1898afb3d29a46b63b1e173a8cff9f384` | `adc30cfe0134b6aab2f63f4cf8ad8ecbb809729a94912318436851e5adfc6809` | `89fb3fb3f7bdbb99a9defa16d02c845ee5ba19440cd126a1e86cdbfe540195a8` | True / 0 |

- f1 files: `movement-unit-687-final-full_lib-f1-20261003.{json,log}`. Actual full `--lib`: **9674 passed / 4 failed / 239 ignored**, log 9942–9959 contains the two missing-moving-projectile panics and Bunker ArriveWait/Occupied mismatch. The fourth failure is the app-in-sim architecture guard, handled independently by Root.
- r6 files: `movement-unit-687-regression-red-r6-20261003.{json,log}`. Actual bounded diagnostic `--lib`: **17 passed / 3 failed / 0 ignored**, 9897 filtered; architecture and app Unit controls passed. Log24–30: both projectile tests recorded **0 moving frames**, Rhino XYZ `[5248,2688,0]`, HP400, terminal Guard5/queued−1/NavNULL, speed fraction0/no adapter; firer stayed Attack1 targeting Rhino, no Nav, last_fire−100. This establishes destination never observed moving at a tick boundary, rather than merely failing the launch-recognition filter. It does not alone prove the command prelude never ran.
- g6 files: `movement-unit-687-regression-green-g6-20261003.{json,log}`. Root's subsequent actual focused run: **30 passed / 0 failed / 0 ignored**, 9887 filtered (17.69s test body). It used corrected Duel type initialization and a larger Bunker fixture (flat map plus locomotor visits in the install loop). Root then reduced Bunker to the single existing Process visit after Enter shown below; f2 validation of that final reduced fixture was pending when this note was saved. No full-suite PASS for the reduced fixture is claimed here.

The source inventories record 1980 f1 and 1981 r6 Rust/Python paths; both receipts report source_unchanged=true. f1's exact `fireat_launch_tests.rs` SHA equals `git show b5f89878:src/sim/combat/fireat_launch_tests.rs`; r6 differs only by Root's bounded actor-state/moving-count diagnostic within this leaf.

## Projectile cause: an incorrectly initialized derived type table

1. Historical `Duel::new` in `src/sim/combat/fireat_launch_tests.rs:186–196` created Simulation, interned the two House names, installed the existing flat arena, then ran `resolve_type_handles`. It did **not** call `intern_rule_type_ids`. The arena already supplies terrain, zones, path grid and playfield (`src/sim/arena_fixture.rs:29–39`); absence of those is not the recorded cause.
2. `TypeHandleTable::build` (`type_handle_table.rs:35–41`) indexes only names already interned. House IDs make this table nonempty. Actor creation later interns MTNK/HTNK/FV in `world_spawn/construction.rs:57–58`, after that table build.
3. `TypeHandleTable::object:74–77` falls back to a name lookup only while the entire table is empty. These later actor IDs therefore return None through `Simulation::object_type` (`world/mod.rs:3043–3048`), even though their real retail RuleSet records exist.
4. New ordinary Unit Move at `world_commands.rs:666–694` uses the existing represented concrete dispatcher. Its nonnull destination preflight at `mission/concrete_effects.rs:197–209` refuses any Unit/Infantry lacking that resolved ObjectType. `assign_destination_represented` (authority.rs:714–731) therefore never calls Unit741970. This is a missing fixture input, not a new class acceptance rule.
5. The Event-shaped prelude at `world_commands.rs:625–632` already queues Move and clears Target **before** destination preflight. Thus terminal Guard/NavNULL is compatible with later Mission processing of the queued Move; do not label the entire command an atomic untouched refusal. Incoming #1047/HEAD directly called the same `set_unit_destination`; `resolve_move_info` tolerated object=None, hiding the fixture defect before dispatch gained preflight.
6. Stationary Grizzly launch/hit tests passed f1 and do not enter this nonnull destination preflight. Their PASS does not certify moving-target prerequisites. The two failing loops test native IsMoving before each tick, then search for a newly retained projectile; their original panic alone was ambiguous, and r6 resolves the motion part.

Existing production startup already supplies the intended identity lifecycle: `app/loading/init.rs:2977→2982` interns all rule IDs then builds the table; scenario startup also does this at2069→2070. Snapshot restoration `app/persistence/mod.rs:260→261` repeats that order without reassigning saved IDs. `world/mod.rs:2978` and `type_handle_table.rs:9–11/34` expressly describe this prerequisite.

Root's current **test-only** correction is `Duel::new:199→200` calling those same owners in production order, plus `spawn:214–219` asserting that the resulting actual actor type resolves. Keep the original lead/fuse/movement assertions; no production cache fallback, new reader, tuning constant or admission weakening is needed.

The diagnostic log binds retail RULESMD from expandmd01.mix to SHA256 `3d341ef8a13a4b5ab24af2eef48ac94931ac2bb87d950fe3330a07e2d25672ef`, 743215B, and fixed ARTMD from ra2md.mix/localmd.mix to `e1f0378394313c04ebbd5073f47785ee3e46f1b3c62d65724e8f3c310ee7ba31`, 336535B. No new layered-type or whole native firing execution is claimed by this fixture diagnosis.

## Bunker cause: the fixture omits the admitted Drive Process visit

Historical `world_commands.rs:3770–3820` explicitly installed an already-live Drive Unit on bunker Cell10,10, revealed it into real cell/Logic membership, then called EnterBunker and drove only six `tick_bunker_install`/body-facing visits. Its supplied rules are the minimal TANK/NATBNK fixture (`bunker_rules`); they are not a stock type-reader comparison.

EnterBunker `world_commands.rs:2132–2144` requests that Cell through `issue_ground_move`. Before this chain, the mapless fixture hit the missing PathGrid return in `ground_move.rs:142–143`, so no destination was armed. The new active-Drive represented-class branch at86–115 executes **before** that gate. Unit's shared Foot/MoveTo tail (`track_path.rs:1179–1184`) publishes NavCom, Drive destination and MovementTarget even when the requested Cell equals the current Cell. Native Drive IsMoving4AFB80 is destination/head based (`track_head.rs:18–27`), not an assertion that distance remains.

Current installation's `on_footprint_and_stopped` (`bunker_install.rs:211–223`) requires physical footprint membership **and** no adapter/no paid head. Without a locomotor visit that newly armed same-cell order remains present, so ArriveWait is the expected current component behavior. Six installation-only visits cannot consume it.

The existing Process prefix (`track_turn.rs:75–82`) resolves this before any search: same-cell Cell NavCom → `track_navcom_stop` → class NULL destination if NavQueue empty → retire idle scheduling adapter (`track_path.rs:568–582`). Root's final minimal fixture at `world_commands.rs:3811–3815` now calls `process_ground_locomotor_stats_for_test(1, Some(&rules), None)` once immediately after Enter, then retains the six install/facing visits and every Occupied/link/Logic/limbo/wall/ejection assertion. That test entry delegates to `process_ground_locomotor_one` (`object_turn.rs:550–557`); the same prefix runs at591 before movement borrows a grid. No added flat map and no per-install Process loops are required for this supplied same-cell prestate.

Actual current production ordering is `world/mod.rs:6300` live-object pass (Unit locomotor included), then `world/mod.rs:6540` Bunker installation. The fixture correction restores that dependency order; it does not certify native whole Bunker scheduling or installation.

## Original byte proof and reproducible read access

Original gamemd.exe is `/Users/halvor/Documents/vera20k-dev/game/Command and Conquer Red Alert II/gamemd.exe`, 5286504B, SHA256 `1cdd1180e49024fbda8ad568caac2e86e856063ff67ab38f62b7d2c7bb84298c`. Existing `native_oracle.configured_gamemd` selects the explicit env path/RA2_DIR; `image_bytes()` verifies this exact SHA before `file_span()` resolves original PE-backed bytes (`tools/native_oracle.py:208–231/260`). No VM, instruction execution or mutation is involved in this read.

Drive's inclusive instruction span **4B066C through RET4 at4B06D2** is `[0x4B066C,0x4B06D5)`, 105B, file offset722540, SHA256 **`4fe7e20273fd13551abb4fb04a2496139b416245c7a34dccee20b40ff1fd6045`**. Unit original vtable7F5C70+1B8 reads41BEA0; +480 reads741970. The original instructions:

- 4B0675–681 require nonnull NavCom whose virtual+2C identifies Cell11.
- 4B0696 calls owner+1B8 (GetCell41BEA0); 4B069C–6AD compares both signed cell words to NavCom Cell+24.
- 4B06AF–6B8 reads complete owner's NavQueue count+598; empty queue reaches4B06C0 push1 /4B06C2 pushNULL /4B06C3 call actor+480.
- 4B06C9 sets AL0; 4B06D2 RET4 exits Process before Facing sampling/ProcessMovement/ProcessTrack. There is no search on this selected prefix.

Reproduce the static read with the existing owners (commands listed for future use; no replay was run for this note):

```sh
cd /Users/halvor/Documents/vera20k-worktrees/vera20k-height
source /Users/halvor/Documents/vera20k-dev/env.sh
PYTHONDONTWRITEBYTECODE=1 python -m tools.native_inspect disasm 0x4B066C --bytes 0x69
PYTHONDONTWRITEBYTECODE=1 python -m tools.native_inspect read 0x4B066C --bytes 0x69
PYTHONDONTWRITEBYTECODE=1 python -m tools.native_inspect disasm 0x458EAF --bytes 0x40
```

Hash verification can call existing `image_bytes()` then `file_span(data,0x4B066C,0x69)` and hash returned bytes; do not synthesize mapped/BSS bytes or infer arithmetic from disassembly. `native_inspect` linear-sweep limits remain in force; the selected starts/true RET are corroborated by the existing caller controls.

Saved **previous original execution**, not newly run: `tools/spatial_oracle/track_outer_continuation.json` SHA256 `6d9fb13b662b05b44ab4497828ea97dca179b39ed78bc0b12cbeb99c0e37a174`; meta `f9ce79bf2f9261a3864da58ea9b86f0c1fe1b8d04333d01f39267bb5d3361032`. Its268 rows contain24 samecell early controls (12 each Drive/Ship). Array row103 (zero-based) is Drive, mission2, current Cell NavCom, queue_count0, receiver_alive1/receiver_return0: actual original GetCell, then observed original Unit+480 identity741970 with arguments[NULL,1], original return AL0.

**Supplied-receiver limit:** that owner intentionally replaces destination/idle receivers with scratch RET8 bodies and supplies NavCom RTTI/IsMoving/coordinate boundaries; it proves original outer predicates/order/arguments, not Unit setter semantics or whole Process/Bunker completion. Existing `track_destination` and `locomotor_moving` are separate original leaf comparisons. `locomotor_force_track`'s bunker rows start at already-selected459190..4591C4 and do not prove Bunker ArriveWait or scheduler cadence.

## Separate Bunker predicate residual retained

Original `[0x458EAF,0x458EEF)`, 64B, file offset364207, SHA256 **`6b7bf70e32fc5ac5251b95111d13bec7e9e304917eff07902f602fd0a3d477c7`**:

- 458EB4 calls candidate+1BC; original Unit7F5C70+1BC is5F6960 (physical Object current Cell), then458EBC calls Cell47C520 and458EC1 requires returned **first ground Building identity == this bunker**.
- 458EC9..458ED6 validates a nonnull active locomotor+674; 458EE4 calls interface virtual+10, and458EE7..458EE9 returns/waits when AL says moving.
- Current `bunker_install.rs:211–223` instead reconstructs footprint membership and tests MovementTarget/committed head. That is an existing explicit #690 approximation, not proof that all current zero-distance adapters are native movement or that footprint inclusion equals ordered first-Building identity.
- Original458E50 first chooses candidate from+2E4 orContacts0 and requiresUnit RTTI1 before the+718 state dispatch. Current installing_unit/BunkerLinkApproaching and global sweep are additional bounded FSM/scheduling differences. The native caller is Building Repair44B780; UnitRepair service and Bunker are different arms. No native complete install/contact/facing/animation/timer/cleanup corpus is established by this packet.

Consequently, repair the **missing same-cell Process dependency in this fixture**, preserve the original assertions, and retain whole-Bunker owner/query/cadence migration as separate required #690 work. Do not silently replace its predicate, interpret this supplied lifecycle test as a parity certificate, or manually null scheduling state to pass it.

## Source pins

SHA256 of raw bytes. `=` means identical to the preceding column. f1/r6 pins come from their immutable receipts; final-current pins were read only under Root's source HOLD at HEAD24330e0 after test simplification. Rows affected by Root's test relocation/diagnostics/fixture changes are deliberately separate.

| Source | f1 receipt | r6 receipt (or =f1) | Final current read (or =r6) |
|---|---|---|---|
| `src/sim/combat/fireat_launch_tests.rs` | `1f884fde25af8cafb4056f8268c54b1a7ba45a1fdde6942681f6859a7b57f27d` | `2e289d7a61b768e3898830e757a402e88ef7a9a5414453485782caa3176d86c9` | `4bfc7bddfe4150a7555a17261988c4b63f4c16ada24d3b3a7ef6b7a6cafdc981` |
| `src/sim/type_handle_table.rs` | `06a2eedd5f7167c3f9fece3fc889aae69a55bb9293b2f84bf2338c791e28e382` | `=` | `=` |
| `src/sim/mission/concrete_effects.rs` | `de3bdf3afc8aae74c57d67fd88128c2174e34c17d7b36f3cc8890ad166c0d350` | `=` | `=` |
| `src/sim/world/world_commands.rs` | `9edc93c11872843ac410fc73066a543717e972ea8e521811699a52d18cdc43a3` | `=` | `5161454c588cf9c2a358fa2c47bb7533d0d69ea856fdbcfba901469e95d80b22` |
| `src/sim/world/ground_move.rs` | `5a781feaaf79c3ecd902f98d1186093f8035223f476ff1910b81a8b880e60b4a` | `=` | `=` |
| `src/sim/world/world_spawn/construction.rs` | `92548090c96388c5b8724335bca09439bbc329355a80f5e0278c8178e11b5aab` | `=` | `=` |
| `src/sim/movement/track_path.rs` | `8e3f05c30c6316662de74e3f8e247bdca08d5f9239d02b1f871f240bd6ccce03` | `=` | `=` |
| `src/sim/movement/track_turn.rs` | `a45f67b088f4db5605f56c715701a1c5ab6af8ceb78ddb4e3ea198dd88add6b4` | `=` | `=` |
| `src/sim/world/object_turn.rs` | `60b6862cca7fdde0a7b27aad36e8a96dab723eda636535b95e07e3f72b157eef` | `=` | `=` |
| `src/sim/world/mod.rs` | `0a64a6fef270a60742c8b35213f5a7080f8dd19ab4855f65db473a8b535a8c2f` | `c0f6e4d0e52fc6a9a7d8ff959bf761511c9996c82678d07c80ca213f5e694709` | `=` |
| `src/sim/docking/bunker_install.rs` | `efd4840d53ba1f4629edf65b3c598719cf8bec1e7cc143b4496728c4d88bac1a` | `=` | `=` |
| `src/app/loading/init.rs` | `9ca58a5bfe3b19343554c6157b9e51a30504fa76978cc9ba46a2b29600a355b0` | `=` | `=` |
| `src/app/persistence/mod.rs` | `e740e34b8f209add60f6ba6a1ac05d695bcf137b9ba5aa2530120e36662c09e9` | `=` | `=` |
| `tools/native_oracle.py` | `141fc5f3981b40d41869643c0350e3988e40be2e470cba8a0b4a77bb7df39b27` | `=` | `=` |
| `tools/native_inspect.py` | `12038060971ec7a41da24e13a9851e23858fba4542c6e9a9f9ca17f3a8252087` | `=` | `=` |
| `tools/spatial_oracle/track_outer_continuation.py` | `91e0b2ef46b08fcbc17eeca410f75a14b61ef7df7305bc839e24592317a426c3` | `=` | `=` |

No assertion or golden was weakened by this research. No native corpus, code, sidecar or archived evidence was changed. Final full f2, original replay and the single later Unit critic remain Root-owned; this note makes no completion claim for the overall movement/height goal.
