"""Derive bounded Rust production facts from an independently validated run."""
from pathlib import Path
import hashlib
import json
import sys

run_dir, offline_path, output_path = map(Path, sys.argv[1:])
assert not output_path.exists(), "Preserve the earlier proof; choose a new path"
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
run_path = run_dir / "run.json"
run = load(run_path)
offline = load(offline_path)
assert offline["status"] == "VALID" and offline["errors"] == []
assert offline["run"]["sha256"] == sha(run_path.read_bytes())
assert run["status"] == "VALID" and run["errors"] == []
assert run["child"]["exit_status"] == 0 and not run["child"]["timed_out"]
assert run["capture"]["exact_step_count"] == 500
observed = run["capture"]["observations"]
commands = observed["commands"]
assert len(commands) == 5
reissue = commands[1]
stop = commands[3]
actor_id = reissue["payload"]["Move"]["entity_id"]
assert stop["payload"]["Stop"]["entity_id"] == actor_id
frames = observed["frames"]
assert len(frames) == 501
actors = []
for frame in frames:
    matches = [actor for actor in frame["actors"] if actor["stable_id"] == actor_id]
    assert len(matches) == 1
    actor = matches[0]
    assert actor["type_id"] == "MTNK" and actor["owner"] == "VERA-OBSERVER"
    assert actor["active"] and not actor["dying"] and not actor["in_limbo"]
    assert "track" in actor["foot"], "Fresh observer field must exist; historical absence is unavailable"
    actors.append(actor)


def paid(actor):
    track = actor["foot"]["track"]
    return bool(track is not None and track["family"] == "Drive" and
                track["valid"] and track["head_leptons"] is not None and
                track["selector"] >= 0 and track["cursor"] > 0)


def sample(step):
    actor = actors[step]
    return {"completed_steps": step, "physical_leptons": actor["physical_leptons"],
            "cell": actor["cell"], "mission": actor["mission"], "nav": actor["nav"],
            "target": actor["target"], "track": actor["foot"]["track"]}

reissue_step = reissue["issue_after_step"]
stop_step = stop["issue_after_step"]
paid_reissue, paid_stop = paid(actors[reissue_step]), paid(actors[stop_step])
reissued_goal = reissue["payload"]["Move"]
reissue_after = actors[reissue_step + 1]
stop_after = actors[stop_step + 1]
assert reissue_after["nav"] == {"Cell": {"rx": reissued_goal["target_rx"],
                                        "ry": reissued_goal["target_ry"]}}
assert stop_after["nav"] is None and stop_after["target"] is None
paid_head_retained_after_reissue = (paid_reissue and
    reissue_after["foot"]["track"]["head_leptons"] == actors[reissue_step]["foot"]["track"]["head_leptons"])
paid_head_retained_after_stop = (paid_stop and
    stop_after["foot"]["track"]["head_leptons"] == actors[stop_step]["foot"]["track"]["head_leptons"])
last_move = commands[-1]["payload"]["Move"]
final_arrival = (actors[-1]["cell"] == [last_move["target_rx"], last_move["target_ry"]] and
                 actors[-1]["nav"] is None and not paid(actors[-1]))
assert final_arrival, "The final ordinary Move must arrive and retire"
steps = sorted({0, 500, *(row["issue_after_step"] for row in commands),
                *(row["issue_after_step"] + 1 for row in commands)})
complete = all((paid_reissue, paid_stop, paid_head_retained_after_reissue,
                paid_head_retained_after_stop, final_arrival))
proof = {"status": "PASS" if complete else "INSUFFICIENT_PAID_HEAD_COVERAGE",
         "classification": "Rust production observation; no native comparison",
         "run_sha256": sha(run_path.read_bytes()), "executable": run["inputs"]["executable"],
         "profile": run["inputs"]["profile"], "map_source": run["capture"]["map_source"],
         "runs": [{"directory": str(run_dir), "offline_validation": str(offline_path),
                   "offline_validation_sha256": sha(offline_path.read_bytes())}],
         "actor_id": actor_id, "exact_step_count": 500, "frame_count": len(frames),
         "command_count": len(commands), "commands": commands,
         "paid_head_before_reissue": paid_reissue, "paid_head_before_stop": paid_stop,
         "paid_head_retained_after_reissue": paid_head_retained_after_reissue,
         "paid_head_retained_after_stop": paid_head_retained_after_stop,
         "final_arrival": final_arrival,
         "distinct_positions": len({tuple(actor["physical_leptons"]) for actor in actors}),
         "paid_head_frames": sum(map(paid, actors)), "boundary_samples": [sample(step) for step in steps],
         "bounds": ["Neutral diagnostic production run; no native image/gameplay comparison.",
                    "Decoded queue=true request exercises compatibility dispatch, not physical Shift.",
                    "Frame snapshots precede commands issued after that step; next frame includes command and Process.",
                    "Paid criterion reads existing valid/head/selector/cursor; it does not derive a head from NavCom.",
                    "Original executable is checked by canonical offline validation; no executable copy is retained."]}
output_path.write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({key: value for key, value in proof.items() if key not in ("boundary_samples", "commands", "runs", "bounds")}, indent=2))
