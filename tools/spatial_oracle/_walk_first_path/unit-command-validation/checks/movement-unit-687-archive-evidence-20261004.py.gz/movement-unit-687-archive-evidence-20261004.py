"""One-off byte-preserving Unit validation packaging; run after runtime passes."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
BASE = Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
NATIVE = BASE / 'movement-unit-native-v1-20261004'
DEST = ROOT / 'tools/spatial_oracle/_walk_first_path/unit-command-validation'
PLAN = BASE / 'movement-unit-687-post-main243-validation-invocation-plan-20261004.json'
PROOF = BASE / 'movement-unit-687-runtime-proof-20261004.json'
OVERLAY = BASE / 'movement-unit-687-bridge-click-test-overlay-f2-20261004.json'
assert not DEST.exists(), 'Preserve any existing archive; do not replace it'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


runs = [
    ('full', 'movement-unit-687-final-full_lib-f2-20261003'),
    ('clippy', 'movement-unit-687-final-clippy_lib-f2-20261003'),
    ('primary63', 'movement-unit-687-final-primary63-f3-20261003'),
    ('python', 'movement-unit-687-final-python_suite-p1-20261003'),
    ('release', 'movement-unit-687-final-release_game-f2-20261003'),
]
receipts = {label: load(BASE / (stem + '.json')) for label, stem in runs}
overlay = load(OVERLAY)
final_sources = receipts['primary63']['source_files']
assert len(final_sources) == 1981
assert receipts['full']['source_files'] == receipts['clippy']['source_files']
prior_sources = receipts['full']['source_files']
assert prior_sources.keys() == final_sources.keys()
changed_sources = [path for path in prior_sources
                   if prior_sources[path] != final_sources[path]]
assert changed_sources == [overlay['changed_source']], changed_sources
assert prior_sources[overlay['changed_source']] == overlay['old_sha256']
assert final_sources[overlay['changed_source']] == overlay['new_sha256']
assert sha(Path(overlay['old_source']).read_bytes()) == overlay['old_sha256']
for label, stem in runs:
    receipt = receipts[label]
    assert receipt['cargo_run_exit'] == 0 and receipt['source_unchanged'], label
    assert not receipt['observed_test_failure'] and not receipt['compile_error'], label
    assert sha((BASE / (stem + '.log')).read_bytes()) == receipt['log_sha256'], label
    assert receipt['invocation_plan_sha256'] == sha(PLAN.read_bytes()), label
    expected_sources = prior_sources if label in ('full', 'clippy') else final_sources
    assert receipt['source_files'] == expected_sources, label
assert receipts['primary63']['test_summaries'] == [['63', '0', '0', '0', '9854']]
assert not receipts['primary63']['fixture_skip_marker']
for relative, digest in final_sources.items():
    assert sha((ROOT / relative).read_bytes()) == digest, relative
focused = load(BASE / 'movement-unit-687-regression-green-g7-20261003.json')
assert focused['cargo_run_exit'] == 0 and focused['source_unchanged']
assert focused['source_files'] == final_sources
assert focused['test_summaries'] == [['1', '0', '0', '0', '9916']]
assert not focused['fixture_skip_marker']
native = load(NATIVE / 'final-native37-handoff.json')
for relative, pin in native['source_pins'].items():
    data = (ROOT / relative).read_bytes()
    assert len(data) == pin['bytes'] and sha(data) == pin['sha256'], relative
proof = load(PROOF)
assert proof['status'] == 'PASS'
assert proof['classification'] == 'Rust production observation; no native comparison'
assert proof['paid_head_before_reissue'] and proof['paid_head_before_stop']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == '24330e019e3875d001fcd16c1141355f8648c3a1', head
DEST.mkdir()
files = {}


def preserve(source, relative, compressed=True):
    data = source.read_bytes()
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), relative
    if compressed:
        with target.open('xb') as stream:
            with gzip.GzipFile(filename='', fileobj=stream, mode='wb',
                               compresslevel=9, mtime=0) as archive:
                archive.write(data)
        assert gzip.decompress(target.read_bytes()) == data
    else:
        target.write_bytes(data)
    assert source.read_bytes() == data, source
    stored = target.read_bytes()
    files[relative] = dict(bytes=len(stored), sha256=sha(stored), gzip=compressed,
                           source=str(source), uncompressed_bytes=len(data),
                           uncompressed_sha256=sha(data))


for label, stem in runs:
    for extension in ('json', 'log'):
        preserve(BASE / (stem + '.' + extension), 'checks/' + label + '.' + extension + '.gz')
for source in sorted(BASE.glob('movement-unit-687-regression-*')):
    if source.suffix in ('.json', '.log'):
        preserve(source, 'regressions/' + source.name + '.gz')
for extension in ('json', 'log'):
    source = BASE / ('movement-unit-687-final-full_lib-f1-20261003.' + extension)
    preserve(source, 'regressions/full-f1.' + extension + '.gz')
    source = BASE / ('movement-unit-687-final-primary63-f2-20261003.' + extension)
    preserve(source, 'regressions/primary63-f2.' + extension + '.gz')
preserve(OVERLAY, 'checks/test-only-source-overlay.json.gz')
preserve(Path(overlay['old_source']),
         'as-run/full-clippy-f2/' + overlay['changed_source'] + '.gz')
for source in [PLAN, BASE / 'movement-target-689-measure-red-20261003.py',
               Path(__file__), BASE / 'movement-unit-687-field-ratchet-main243-20261004.txt',
               BASE / 'movement-unit-f1-r6-fixture-causal-b5f89878-20261004.md',
               BASE / 'movement-unit-drive-bunker-original-spans-root-readback-20261004.json',
               BASE / 'movement-unit-687-runtime-proof-20261004.py']:
    preserve(source, 'checks/' + source.name + '.gz')
for name in ['final-native37-handoff.json', 'root-final-native37-integrity.json',
             'root-native37-integrity-after-main243.json', 'checkpoint-final-native37.md']:
    preserve(NATIVE / name, 'native/' + name + '.gz')
for name in native['terminal_checks']:
    preserve(NATIVE / name, 'native/' + name + '.gz')
for relative in native['source_pins']:
    if relative.endswith(('.json', '.md')):
        preserve(ROOT / relative, 'native/as-run/' + relative + '.gz')
changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=ROOT,
                                     text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'],
                                      cwd=ROOT, text=True).splitlines())
for relative in sorted(changed):
    if relative.endswith(('.rs', '.py')) and (ROOT / relative).is_file():
        preserve(ROOT / relative, 'as-run/' + relative + '.gz')
diff = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT)
diff_path = BASE / 'movement-unit-687-final-candidate-main243-20261004.diff'
assert not diff_path.exists()
diff_path.write_bytes(diff)
preserve(diff_path, 'as-run/candidate.diff.gz')
preserve(PROOF, 'runtime/proof.json.gz')
for run in proof['runs']:
    directory = Path(run['directory'])
    offline = Path(run['offline_validation'])
    assert load(offline)['status'] == 'VALID', offline
    preserve(offline, 'runtime/' + directory.name + '/offline.json.gz')
    for source in sorted(directory.rglob('*')):
        if source.is_file() and source.name != 'config.toml':
            relative = source.relative_to(directory).as_posix()
            preserve(source, 'runtime/' + directory.name + '/' + relative + '.gz')
for source in sorted((BASE / 'movement-unit-687-runtime-inputs-20261004').iterdir()):
    if source.is_file():
        preserve(source, 'runtime/inputs/' + source.name + '.gz')
manifest = dict(schema_version=1, scope='Ordinary MTNK Cell command owner chain',
                classification='Bounded executed native command comparisons plus Rust regression/production validation',
                base=head, native_sha256=native['native_sha256'],
                native_manifest_sha256=native['source_pins']['tools/spatial_oracle/_walk_first_path/manifest.json']['sha256'],
                native_histories=len(native['rows']), unit_histories=len(native['unit_receipts']),
                runs={label: {key: receipt.get(key) for key in
                             ('argv', 'cargo_run_exit', 'wall_seconds', 'source_identity',
                              'test_summaries', 'fixture_skip_marker', 'log_sha256')}
                      for label, receipt in receipts.items()},
                test_only_source_overlay=overlay,
                runtime=proof, files=files,
                bounds=native['coverage_bounds'] + [
                    'Paid original AI priors are imported for Rust command comparisons; whole AI is not replayed.',
                    'Retail release observation is Rust production evidence, not native pixel/gameplay equivalence.',
                    'Decoded queue compatibility input is not a physical keyboard Shift observation.',
                    'Bunker fixture fixes movement cadence; complete Bunker owner/query/cadence remains #690.',
                    'Ship naval factory prewrite/queue migration and other adapters remain #687/#689.',
                    'GI validation remains unchanged; its b90 native identity resolves to the pre-Unit manifest seal.',
                    'Runtime machine config bytes are omitted; original identities remain in run receipts.',
                    'Full/Clippy f2 precede one test-only bridge assertion migration; original bytes are retained, and focused g7/primary63 f3 validate the final assertion.',
                ])
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(archive=str(DEST), files=len(files),
                      manifest_sha256=sha((DEST / 'manifest.json').read_bytes()))))
