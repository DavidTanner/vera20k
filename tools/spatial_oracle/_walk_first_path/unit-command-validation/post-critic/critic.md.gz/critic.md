# Independent Unit movement-command critic — main1050 candidate

2026-10-04. One fresh read-only pass by an agent that did not implement the change. Reviewed `/Users/halvor/Documents/vera20k-worktrees/vera20k-height`, dirty branch `feature/unit-move-command-owner`, base `a8b4303a637958cb22125cbee14fc97e23ffce2f`. Read `AGENTS.md`, `.agents/skills/_shared/review.md`, the final packet, original evidence, implementation and affected callers. This report is the only external file written by this pass. No source, corpus, metadata, archive, Git/GitHub, process or Ghidra mutation; no Cargo, game or native VM execution.

## Findings and disposition

**No P0–P2 implementation defect or missing merge prerequisite was established for the bounded ordinary MTNK command-owner change.** The change can be assessed as one validated command/retask mechanism, with the evidence bounds below. This does not establish complete movement, navigation, height, sight, factory or AI parity, and does not close the broader goal.

The sight bootstrap defect is real prerequisite work for the next sight/arrival chain. The accepted native command histories remain useful conditional comparisons against their explicit revealed-view and imported paid-head priors. They cannot establish a physical native footprint or a native full-arrival continuation. Keeping those distinctions is necessary when describing this PR.

### Worthwhile in-scope refactors, nonblocking

1. **[P3] Give the represented Drive Unit cohort one query owner.** Trigger: a future extension changes which installed locomotor/class combination uses the ordinary Unit path. The same `unit_setter_receiver && active_kind == Drive` decision is repeated in [the input producer](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/src/app/input/commands.rs:858), [the decoded-command deployment exception](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/src/sim/world/world_commands.rs:595) and [the internal ground-order dispatch](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/src/sim/world/ground_move.rs:86); [the input guard](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/src/sim/world/move_cell_input.rs:86) also spells the Unit/Drive classification directly. Consequence: independently changing one can split Shift normalization, Event admission and internal caller dispatch for the same actor. These predicates currently agree; this is a maintenance risk, not a demonstrated current gameplay defect. A read-only classification query beside the existing class receiver owner would remove that repeated decision without adding a setter wrapper, copied port or state. Keep its precise ordinary-Drive scope; do not silently fold Ship or other families into it.

2. **[P3] Correct the migrated unload consumer's stale path-admission description.** Trigger: tracing the vehicle-passenger `Set_Destination(cell,1)` caller through [transport_unload.rs](/Users/halvor/Documents/vera20k-worktrees/vera20k-height/src/sim/transport_unload.rs:348). Its comment still calls this a “pathed move” and says a missing PathGrid prevents movement. The new Drive branch in `issue_ground_move` reaches the class setter before the PathGrid acquisition at line 142; the setter accepts a destination independently of route availability, and Process owns the later search. Consequence: the comment points future fixture and integration work at the superseded admission model, the very distinction this migration fixes. Update the comment, and consider the helper's name if doing a small local cleanup. No functional change is needed for this observation.

## Ownership and production reachability

The production sequence is now coherent for the reviewed corridor:

- App ordinary Cell input resolves through the existing Foot4DE1D0 owner, normalizes literal Shift to an ordinary Move and uses the existing ordinary record codec. The new app test module calls the actual producer and codec; simulation tests supply only the callback boundary. There is no runtime simulation dependency on app code.
- Decoded Move performs the Event retask/Target prefix before the represented void class destination dispatch. The delayed-deployed control establishes why class refusal cannot be treated as physical input refusal. The original Event instructions at `4C73B9`, `4C7467` and `4C747C` respectively queue the mission, assign Target and call destination with flag 1, in that order.
- Internal Drive `GroundMove` reaches `assign_destination_represented` and the existing `set_unit_destination` owner before any path grid, movement block cache or eager path acquisition. This fixes the former accepted-tail composition. The class remains the authority for same-NavCom, force, deployment, radio and queue decisions. No new Unit741970 body or competing destination state was introduced.
- The existing Foot/locomotor owners still own NavCom, captured destination XYZ, paid head and Foot+5E0. NavCom identity, a class-sampled coordinate, a paid segment and a waypoint queue have different native lifetimes. Combining them would break same-target and Stop/reissue behavior.
- `MovementTarget.final_goal` is cleared for Walk/Drive/Ship scheduling and retained paid movement. `movement_goal_cell` is a read-only presentation projection of existing NavCom/destination/head authorities. A source-wide consumer search found no remaining production Drive/Ship simulation decision consuming the removed goal copy; remaining `final_goal` decisions belong to the other adapters. Track speed reads the installed locomotor destination and retained target fraction. Updated debug consumers do not feed the projection back into simulation.
- The ordinary nonqueued command branch still covers other represented Unit locomotors through their existing shared setter. Its new returned-true behavior reports a dispatched void call, not acceptance by a particular Move_To implementation. Their already represented class logic remains shared. This review does not certify every one of those other input or locomotor mechanisms.

I traced the affected internal callers in movement/path redirects, order resumption, pursuit, AttackMove, vehicle unload and bunker entry, and the existing miner and naval-production routes. The miner paths that already use the Unit setter retain that owner. Ship's naval-factory prewrite/queue composition remains an explicitly separate consumer problem; this change did not silently migrate that path. A context-free legacy adapter remains for unrepresented families/fixtures. Its existence does not create a second selected ordinary Drive class path when production rules are available, but it remains part of the broader ownership audit.

The Duel fixture correction binds rule identities before constructing the derived type table, matching production resolution. It does not alter combat behavior. The bunker component fixture now consumes an actual same-cell Drive Process before running installation. Production visits movement before installation, and the original same-cell Drive prefix owns that destination consumption; merely asserting a stopped tank immediately after destination assignment would have hidden a missing prerequisite. This correction does not demonstrate the whole bunker `+10`, arrival or installation cadence (#690).

## Independent evidence checks

### Original executable and static body/caller evidence

I selected the original executable through the repository's `native_oracle.image_bytes`/`file_span` and `native_inspect` owners, with bytecode writing disabled. SHA256 was `1cdd1180e49024fbda8ad568caac2e86e856063ff67ab38f62b7d2c7bb84298c`. These were static reads and disassembly, not native execution. Bridge instance discovery returned no instances; I did not start or modify Ghidra.

Original bytes independently confirm:

- Unit `741A80..741ADA`: same NavCom returns before the force/deployment writes unless `+1F8` is set; the class then clears `+1F8`, examines `+6E0/1/2`, and uses the distinct `+2B0` exemption. The Rust owner explicitly bounds the unrepresented `+2B0` producer; no Magnetron identity is justified. The tested MTNK controls have literal `+2B0=0`.
- Unit CellClick `738910..738968`: the `+6E0` requery and Berserk refusal precede Foot ClickedAction. Full Unit WhatAction `7404B0..74080F` retains its shroud query and deployment suffix. The original Unit vtable's `+2C` leaf at `746E20` returns1; the Infantry leaf at `523340` returns15. The grounded Unit resolver does not take the Aircraft/high-flight special action2 arm. Treating action1/action2 identically inside the port's stated ground/non-Teleporter domain is supported by the instruction branch structure and the executed outside-playfield contrast, rather than a guessed enum meaning.
- Foot resolver `4DE1D0..4DE577` still queries visibility at `4DE3B5` even with MoveToShroud enabled. The existing 29 admission comparisons include a supplied Unit/Drive shrouded-cell row, but supply the input action selector. They are leaf resolver evidence, not complete Unit query/bootstrap evidence.
- Move Event `4C7353..4C74B2` preserves queue/Target/destination ordering and discards the destination result. The existing class implementation result is not a native Event acceptance BOOL.
- IsShrouded `586360..586495`, on the observed flat worldZ0 route, tests Cell `+12C bit8`. It does not consult `+130/+134` or `+120/+121` there.
- Unit full-arrival suffix `73AC52..73ACD7` calls Lose, then See, then Map cache traversal before the later Ready/Commence sequence. This dependency is outside the retained paid prefix and cannot be dropped from the later #692 work.

Complete function/fragment checksums matched the prerequisite report for Unit WhatAction (`67b10efb...`), Foot resolver (`5f8c8266...`), IsShrouded (`d6309317...`), Move Event (`3d526bff...`) and Unit arrival (`32c06891...`). Those full reads decoded with no undecoded bytes. For any shortened interior diagnostic span, I used the enclosing function decode to interpret boundaries; a linear interior sweep alone was not treated as a control-flow proof.

### Retained executed native comparisons

I ran only the existing **saved-evidence** selector `saved_gi_reissues`, which checks raw/source/hash bindings and mechanically selects receipts without emulation. It reselected all 37 histories exactly equal to current `walk_first_path.json`: GI 21 plus Unit 16. The active manifest SHA is `eb53699b9766cc3958a132e1f51c1fe5ec442cefaa057afeb4803640544ebd58`; it is not the sealed historical GI validation manifest `b90c182f...`.

Independent raw-receipt readback found Unit class true RETs at `743170` and `743184` with original SP+12, ordinary and literal-Shift same-target no-ops, later-frame replacement and the delayed-deployment Event-prefix/refusal split. Negative House/Berserk/deployment inputs emit no Event/class call. The outside control records actual query 2 on Cell 4,20, Foot/FNPC resolution to 4,19, then ordinary Event/class delivery. Source maps, failed attempts and prior receipts remain preserved rather than relabelled.

The three paid histories each retain two Scenario requests and three raw advances from their original AI prior. Command-only histories have zero requests/advances. The class/input/Event boundaries make no draw in the selected observations. Full Main/Scenario/Mapgen state remains in the source-bound receipts and is compared by the Rust command checks. These are observed coverage limits, not a universal no-RNG claim for Unit AI or other class branches.

### Sight prerequisite challenge and readback

I inspected the supplied sight-bootstrap report as evidence, not authority. Current source omits the two spread CRT producers from this joined composition; original data slots `813AA4..813AAC` contain 561900/5638C0, and original radius-count data at `7ED3D0..7ED400` is `[1,9,21,37,61,89,121,161,205,253,309,369]`. Static data hashes matched `43896e45...` and `ad889698...`. The source uses zero-filled mapped Cells rather than a complete original Cell constructor, and supplies `+12C=0x18` across the map before original source admission.

I independently decoded all 16 full accepted Unit histories. Every baseline has 1024 Cells with `+12C=0x18`. The same four nonzero sight-count centers are retained:11,8=`[-205,0]`, and14,14/14,16/16,16=`[-89,0]`. Every initial source actor has 250=1,254=`[2944,2176,0]`,260=8,264=0. The record contains zero writes to Cell130/134, Cell120/121 or actor 250..267 in all 16 continuations. The paid original AI visits 1..8 do not leave `[2944,2176,0]`; visit 9 reaches `[2955,2187,0]`, and the next reaches `[2974,2206,0]` or `[2961,2193,0]` after Stop. These are still Cell 11,8, and no full paid-head arrival is demonstrated.

The concentrated counts support the cold-offset causal explanation, but the old receipts do not export the spread tables or the complete first-source See trace. Omitted initialization is source-inspected configuration; actual table contents at every observation are not an executed readback. The collector watches writes/calls, not every memory read. Zero recorded sight writes cannot prove global table independence or exclude all nested cache readers in whole UnitAI. The report and new archived scope note correctly retain that uncertainty.

The Rust fixture explicitly reveals its supplied view through the existing fog owner before comparing commands, and imports native-paid locomotor/mission/path/timer/RNG priors for paid tests. It does not attempt a Rust replay of the nine original whole-AI visits. Therefore the cold footprint is not silently being used to claim a correct sight producer, physical footprint or full-arrival result. Repairing startup/cadence requires fresh correctly initialized native evidence in the later chain, while preserving these historical receipts. Resetting counters or admission bytes after bootstrap would not establish that prerequisite.

### Rust regression and production evidence

I inspected, but did not rerun, the final retail logs and receipts. Compressed and uncompressed hashes matched for all 72 supplement files. All 1,982 current source-file hashes matched its census, and each of the five recorded check censuses was identical and source-unchanged. All 11 final native source/data pins matched current bytes. The supplement manifest observed during this pass is `88a9b7490e6a92e1a3a2a775535eb900c4b74cd76dc2470b59eeb2a6f82f0676`; the earlier 71-file manifest is preserved in the documentation addendum.

| Saved check | Actual retained result | Evidence level |
|---|---|---|
| Final retail library f4 | 9,682 passed, 0 failed, 239 ignored | Rust regression; original terminal log/hash checked |
| Final Clippy f4 | exit 0, 723 warnings | Rust static check; no warning-free claim |
| Required retail primary63 f4 | 63 passed, 0 failed, 0 ignored, no fixture skips | Connected retail regression |
| Python p2 | 613 tests, 5 optional skips, successful | Tooling regression |
| Fresh release f4 | exit 0; matching candidate census | Build evidence |
| Field ratchet | saved exit 0;2,505 versus2,505 | No increase in crate-writable sim fields |
| Production observation r2 | 500 steps, 501 frames, 5 decoded commands;49 physical positions and 47 paid-head frames | Rust runtime observation, no native comparison |

The app tests exercise the actual producer/codec and the shared simulation fixture against original returned state. The internal same-destination regression exercises the production `GroundMove` boundary with and without a published grid, against the original supplied-prior Unit row. Stop/paid command comparisons check original locomotor head/progress/destination/fraction and Foot path/timer state; fraction fixture decoding expressly does not certify native floating-point conversion or the full movement arithmetic.

The saved release observation uses binary SHA `da5918a5864d4f0dfa26d762448c0b03afad25c84f373cf66277bad66e1007a5`, run SHA `4071508f0f31f4216e24db22243b90abd7c602c86b8fbe6720ef607f4386c439`. Its samples show a real paid segment before reissue, head retention across B and Stop, continued physical motion and final arrival/retirement. Queue=true in this profile is a decoded compatibility command, not physical Shift. The additive track observation reads installed owner state without creating runtime or issuing callbacks; historical absence of that optional observation is unavailable evidence. This record establishes production reachability and continued behavior, not rendered gamemd or whole native AI parity.

## Remaining coverage and goal boundary

Keep these explicit in the PR and checkpoint:

- Native whole startup/physical sight geometry, complete movement-to-full-arrival sight release/readmit and high-flight cadence are still required #692 work. No global spread-table independence or wholeAI/bootstrap parity was established.
- The imported paid native prefix and the full Rust runtime continuation are different evidence levels. Together they do not certify a whole native/Rust AI loop, whole scheduler or arbitrary-map movement arithmetic.
- Literal Shift is covered at the original input and actual Rust producer/codec boundaries. Physical Windows mouse/keyboard delivery, display hit testing, Planning Mode and networking/save-load protocols were not reviewed as complete mechanisms.
- Ship naval-factory NavCom prewrite/queue caller, other legacy queued adapters and traffic/continuation ownership (#687/#689/#972), full bunker arrival/install cadence (#690), other class/action/high/Teleport routes and AttackMove remain open mechanisms. They must not be labelled complete through this pass.
- Native timer padding remains retained in evidence while Rust compares its existing anchor/duration owner. No new timer arithmetic or RNG algorithm was introduced by this refactor. Native raw Techno2B0 producer identity remains unproved.
- This pass did not rerun Cargo, native histories or the game, nor establish renderer/performance/platform parity. It checked saved results, source identity, original bytes, original preserved observations and the connected implementation paths.

One critic pass is complete. The owner can act on the two nonblocking maintenance observations and independently validate any edits. No follow-up or replacement critic is requested. **HOLD.**
