from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path(__file__).resolve().parent
cwd = root.parents[2]
manifest_path = Path('/Users/halvor/Documents/vera20k/.git/owned-builds/artifacts/depot-service-hash-attribution-20261003/manifest.json')
manifest = json.loads(manifest_path.read_bytes())
artifact = manifest['artifacts'][0]
binary = manifest_path.parent / artifact['file']
expected_sha = artifact['sha256']
command = [str(binary), '--exact', 'sim::world::global_parity_harness_tests::global_skirmish_replay_is_deterministic_and_baseline_stable', '--nocapture']
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_sha
for mode, enabled in (('control','1'), ('current',None)):
    output = root / mode
    output.mkdir(exist_ok=False)
    env = os.environ.copy()
    env['VERA20K_REQUIRE_RETAIL_INI'] = '1'
    env['VERA20K_REPLAY_DIAGNOSTICS'] = str(output)
    gate = 'VERA20K_DIAGNOSTIC_LEGACY_BUILDING_HASH'
    env.pop(gate, None)
    if enabled is not None: env[gate] = enabled
    started = time.monotonic()
    with (root / (mode + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt = dict(schema_version=1, mode=mode, command=command, cwd=str(cwd), exit_code=result.returncode, seconds=time.monotonic()-started,
        binary_sha256=expected_sha, binary_unchanged=hashlib.sha256(binary.read_bytes()).hexdigest()==expected_sha,
        source_sha256=manifest['source']['source_sha256'], legacy_building_hash=enabled)
    (root / (mode + '.execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'mode':mode,'exit':result.returncode,'seconds':receipt['seconds'],'binary_unchanged':receipt['binary_unchanged']}), flush=True)
    if result.returncode or not receipt['binary_unchanged']:
        print((root / (mode + '.log')).read_text()[-5000:],flush=True)
        raise SystemExit(1)
