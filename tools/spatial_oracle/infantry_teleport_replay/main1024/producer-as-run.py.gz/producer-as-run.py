from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
repo=Path('/Users/halvor/Documents/vera20k-worktrees/vera20k-height')
base=Path('/Users/halvor/Documents/vera20k-dev/refactor-goal')
name='sim::world::global_parity_harness_tests::global_skirmish_replay_is_deterministic_and_baseline_stable'
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'incoming_main':'9bee532acb1c86b7edffb774743ba69d1704579f','runs':[]}
freeze={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'src').rglob('*.rs')}
receipt['source_freeze_sha256']=hashlib.sha256(json.dumps(freeze,sort_keys=True).encode()).hexdigest()
for mode in ('control','current'):
 env=os.environ.copy();env.update(RA2_DIR='/Users/halvor/Documents/vera20k-dev/game/Command and Conquer Red Alert II',VERA20K_REQUIRE_RETAIL_INI='1',VERA20K_REQUIRE_RETAIL_ASSETS='1')
 for key in ('C3Y02MD','C3Y03MD','XMP34U4'):env['VERA20K_'+key+'_MAP']=str(base/'movement-retail-fixtures-20261002/extract'/f'{key}.MAP')
 for key in ('VERA20K_ANYTOWN_MAP','VERA20K_SHRAPNEL_MAP'):env.pop(key,None)
 if mode=='control':env['VERA20K_CLEG_ABSENT_TAG_CONTROL']='1'
 else:env.pop('VERA20K_CLEG_ABSENT_TAG_CONTROL',None)
 diag=base/f'cleg-main1024-hash-{mode}-20261003';assert not diag.exists();diag.mkdir()
 env['VERA20K_REPLAY_DIAGNOSTICS']=str(diag)
 log=base/f'cleg-main1024-hash-{mode}-20261003.log';assert not log.exists()
 print('START',mode,flush=True);start=time.monotonic()
 with log.open('w') as f:r=subprocess.run([sys.executable,'-m','tools.cargo_run','--','test','-p','vera20k','--lib',name,'--','--exact','--nocapture','--test-threads=1'],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 content=log.read_text();summary=re.findall(r'test result:.*',content)
 row={'mode':mode,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'summary':summary,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'trace':str(diag/'global.jsonl')}
 receipt['runs'].append(row)
 (base/'cleg-main1024-hash-control-20261003.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('TERMINAL',mode,r.returncode,summary,flush=True)
 assert freeze=={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'src').rglob('*.rs')},'Source drift'
 if mode=='control' and r.returncode:
  print('\n'.join(line for line in content.splitlines() if any(x in line for x in ('error[','error:','panicked at','left:','right:','FAILED')))[:4000],flush=True);raise SystemExit(r.returncode)
 if mode=='current':assert r.returncode==101 and 'global harness final hash moved' in content,content[-2500:]
 assert 'SKIPPED:' not in content and 'Skipping' not in content
rows={mode:[json.loads(line) for line in (base/f'cleg-main1024-hash-{mode}-20261003/global.jsonl').read_text().splitlines()] for mode in ('control','current')}
assert len(rows['control'])==len(rows['current'])==601
hashes={mode:rows[mode][-1]['tick_result']['state_hash'] for mode in rows}
for mode in rows:
 for row in rows[mode]:
  if row['tick_result'] is not None:row['tick_result'].pop('state_hash')
assert rows['control']==rows['current'],'Non-hash replay difference'
receipt.update(rows_compared=601,only_difference='tick_result.state_hash',final_hashes=hashes)
(base/'cleg-main1024-hash-control-20261003.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS: 601 complete rows equal except hash; final', {k:f'{v:016X}' for k,v in hashes.items()},flush=True)
