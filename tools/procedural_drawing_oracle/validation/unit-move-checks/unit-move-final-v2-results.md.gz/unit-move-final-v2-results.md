# Final Move release replay

PASS: all twelve actual Move release replays are VALID and `compare_family("unit-move", ...)` passes, including every native-bound v1 frame and observation. The rally compatibility replay also passes the existing `compare_runs` owner.

- Source: `d5b667327a69b2a2d16578e938cfc8382a0820ed`.
- Label: `procedural-unit-move-production-v2`.
- Executable SHA-256: `776a416bc6645aa0da3137b207012fd5cf51a3516e99a81fb4da79a5e7d9c4c5`.
- Native action packet SHA-256: `36bf5a7d66970e077d4b2301d50a7fcfa31957402889f70947225d8f309a6cad`.
- Move equality: 12 complete 800×600 BGRA frames (5,760,000 pixels), 385 observed boundaries; zero differences.
- Rally equality: one complete 800×600 BGRA frame and all 1,501 observed boundaries against `rally-clear-v4`; zero differences.
- All captures used the existing map-observation owner, original sealed profile/contract, approved Python, absolute paths and `env -u RA2_DIR`.

| Replay | Observed boundaries | Result |
| --- | ---: | --- |
| unit-move-active-v1 | 7 | VALID; exact frame and observations |
| unit-selected-only-v1 | 7 | VALID; exact frame and observations |
| unit-move-before-stop-v1 | 8 | VALID; exact frame and observations |
| unit-move-stopped-v1 | 8 | VALID; exact frame and observations |
| unit-move-last-active-v1 | 30 | VALID; exact frame and observations |
| unit-move-expired-v1 | 31 | VALID; exact frame and observations |
| unit-move-expired-next-v1 | 32 | VALID; exact frame and observations |
| unit-move-reselect-v1 | 32 | VALID; exact frame and observations |
| empty-band-unselected-v1 | 6 | VALID; exact frame and observations |
| unit-move-empty-band-restart-v1 | 32 | VALID; exact frame and observations |
| unit-move-arrived-control-v1 | 96 | VALID; exact frame and observations |
| unit-move-arrived-reselect-v1 | 96 | VALID; exact frame and observations |

Visual inspection of the losslessly decoded active, stopped, reselected and arrived frames matches the expected visible states:
- `unit-move-active-v1`: Thin green order line joins the selected MTNK to its destination; tank and health bar remain visible.
- `unit-move-stopped-v1`: Selected MTNK remains visible; the green order line is absent after Stop.
- `unit-move-reselect-v1`: Green order line is restored from the moved MTNK position to the same destination.
- `unit-move-arrived-reselect-v1`: MTNK has arrived and remains selected; no order line appears with null NavCom despite the restarted timer.

Initial wrapper setup error: the intended shared `unit-move-final-v2` parent directory did not exist. All twelve initial Move commands were rejected before any child launch. The exact errors were retained in `unit-move-final-v2-wrapper-setup-errors.json`; creating the ignored parent was the only repair. The rally replay completed first, then all twelve Move replays ran sequentially. No source, configuration, profiles, native evidence, archives or refs were changed; no Cargo ran.

Detailed result: `unit-move-final-v2-results.json`. Rally comparison: `rally-clear-unit-move-v2-comparison.json`. Lossless inspection PNGs: `unit-move-final-v2-inspection/`.

Evidence boundary: native comparisons use prepared captured inputs and certify the stored procedural line samples, not native Scenario construction or a full native frame. The whole procedural drawing goal remains open. Cadence metadata is the existing frame-boundary wall mean, not GPU duration or ordinary-play FPS.

Shared live comparator follow-up: `tools.map_observation.compare_runs` returned MATCH for every one of the twelve Move v1/v2 pairs, with no errors or differences. This additionally checks sealed input bytes, diagnostic clock and unit atlas through their existing owner. Compact results: `unit-move-final-v2-map-comparisons.json`.
